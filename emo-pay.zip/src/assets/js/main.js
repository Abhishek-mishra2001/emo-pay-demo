
(function() {
  "use strict";

  /**
   * Easy selector helper function
   */
  const select = (el, all = false) => {
    el = el.trim()
    if (all) {
      return [...document.querySelectorAll(el)]
    } else {
      return document.querySelector(el)
    }
  }

  /**
   * Easy event listener function
   */
  const on = (type, el, listener, all = false) => {
    let selectEl = select(el, all)
    if (selectEl) {
      if (all) {
        selectEl.forEach(e => e.addEventListener(type, listener))
      } else {
        selectEl.addEventListener(type, listener)
      }
    }
  }

  /**
   * Easy on scroll event listener 
   */
  const onscroll = (el, listener) => {
    el.addEventListener('scroll', listener)
  }

  /**
   * Navbar links active state on scroll
   */
  let navbarlinks = select('#navbar .scrollto', true)
  const navbarlinksActive = () => {
    let position = window.scrollY + 200
    navbarlinks.forEach(navbarlink => {
      if (!navbarlink.hash) return
      let section = select(navbarlink.hash)
      if (!section) return
      if (position >= section.offsetTop && position <= (section.offsetTop + section.offsetHeight)) {
        navbarlink.classList.add('active')
      } else {
        navbarlink.classList.remove('active')
      }
    })
  }
  window.addEventListener('load', navbarlinksActive)
  onscroll(document, navbarlinksActive)

  /**
   * Scrolls to an element with header offset
   */
  const scrollto = (el) => {
    let header = select('#header')
    let offset = header.offsetHeight

    if (!header.classList.contains('header-scrolled')) {
      offset -= 20
    }

    let elementPos = select(el).offsetTop
    window.scrollTo({
      top: elementPos - offset,
      behavior: 'smooth'
    })
  }

  /**
   * Toggle .header-scrolled class to #header when page is scrolled
   */
  let selectHeader = select('#header')
  if (selectHeader) {
    const headerScrolled = () => {
      if (window.scrollY > 100) {
        selectHeader.classList.add('header-scrolled')
      } else {
        selectHeader.classList.remove('header-scrolled')
      }
    }
    window.addEventListener('load', headerScrolled)
    onscroll(document, headerScrolled)
  }

  /**
   * Back to top button
   */
  let backtotop = select('.back-to-top')
  if (backtotop) {
    const toggleBacktotop = () => {
      if (window.scrollY > 100) {
        backtotop.classList.add('active')
      } else {
        backtotop.classList.remove('active')
      }
    }
    window.addEventListener('load', toggleBacktotop)
    onscroll(document, toggleBacktotop)
  }

  /**
   * Mobile nav toggle
   */
  on('click', '.mobile-nav-toggle', function(e) {
    select('#navbar').classList.toggle('navbar-mobile')
    this.classList.toggle('bi-list')
    this.classList.toggle('bi-x')
  })

  /**
   * Mobile nav dropdowns activate
   */
  on('click', '.navbar .dropdown > a', function(e) {
    if (select('#navbar').classList.contains('navbar-mobile')) {
      e.preventDefault()
      this.nextElementSibling.classList.toggle('dropdown-active')
    }
  }, true)

  /**
   * Scrool with ofset on links with a class name .scrollto
   */
  on('click', '.scrollto', function(e) {
    if (select(this.hash)) {
      e.preventDefault()

      let navbar = select('#navbar')
      if (navbar.classList.contains('navbar-mobile')) {
        navbar.classList.remove('navbar-mobile')
        let navbarToggle = select('.mobile-nav-toggle')
        navbarToggle.classList.toggle('bi-list')
        navbarToggle.classList.toggle('bi-x')
      }
      scrollto(this.hash)
    }
  }, true)

  /**
   * Scroll with ofset on page load with hash links in the url
   */
  window.addEventListener('load', () => {
    if (window.location.hash) {
      if (select(window.location.hash)) {
        scrollto(window.location.hash)
      }
    }
  });

  /**
   * Testimonials slider
   */
  new Swiper('.testimonials-slider', {
    speed: 600,
    loop: true,
    autoplay: {
      delay: 5000,
      disableOnInteraction: false
    },
    slidesPerView: 'auto',
    pagination: {
      el: '.swiper-pagination',
      type: 'bullets',
      clickable: true
    },
    breakpoints: {
      320: {
        slidesPerView: 1,
        spaceBetween: 20
      },

      1200: {
        slidesPerView: 2,
        spaceBetween: 20
      }
    }
  });

  /**
   * Porfolio isotope and filter
   */
  window.addEventListener('load', () => {
    let portfolioContainer = select('.portfolio-container');
    if (portfolioContainer) {
      let portfolioIsotope = new Isotope(portfolioContainer, {
        itemSelector: '.portfolio-item',
        layoutMode: 'fitRows'
      });

      let portfolioFilters = select('#portfolio-flters li', true);

      on('click', '#portfolio-flters li', function(e) {
        e.preventDefault();
        portfolioFilters.forEach(function(el) {
          el.classList.remove('filter-active');
        });
        this.classList.add('filter-active');

        portfolioIsotope.arrange({
          filter: this.getAttribute('data-filter')
        });
        portfolioIsotope.on('arrangeComplete', function() {
          AOS.refresh()
        });
      }, true);
    }

  });

  /**
   * Initiate portfolio lightbox 
   */
  const portfolioLightbox = GLightbox({
    selector: '.portfolio-lightbox'
  });

  /**
   * Portfolio details slider
   */
  new Swiper('.portfolio-details-slider', {
    speed: 400,
    loop: true,
    autoplay: {
      delay: 5000,
      disableOnInteraction: false
    },
    pagination: {
      el: '.swiper-pagination',
      type: 'bullets',
      clickable: true
    }
  });

  /**
   * Animation on scroll
   */
  window.addEventListener('load', () => {
    AOS.init({
      duration: 1000,
      easing: 'ease-in-out',
      once: true,
      mirror: false
    })
  });

})()


// hero slider 
// const carouselFrame = document.querySelector('.carousel-frame');
// const carouselSlide = document.querySelector('.carousel-slide');
// const carouselImages = getImagesPlusClones();
// const prevBtn = document.querySelector('.carousel-prev');
// const nextBtn = document.querySelector('.carousel-next');
// const navDots = Array.from(document.querySelectorAll('.carousel-dots li'));

// let imageCounter = 1;

// function getImagesPlusClones() {
//   let images = document.querySelectorAll('.carousel-slide img');

//   const firstClone = images[0].cloneNode();
//   const lastClone = images[images.length - 1].cloneNode();

//   firstClone.className = 'first-clone';
//   lastClone.className = 'last-clone';

//   // we need clones to make an infinite loop effect
//   carouselSlide.append(firstClone);
//   carouselSlide.prepend(lastClone);

//   // must reassign images to include the newly cloned images
//   images = document.querySelectorAll('.carousel-slide img');

//   return images;
// }

// function initializeNavDots() {
//   if (navDots.length) navDots[0].classList.add('active-dot');
// }

// function initializeCarousel() {
//   carouselSlide.style.transform = 'translateX(-100%)';
// }

// function slideForward() {
//   // first limit counter to prevent fast-change bugs
//   if (imageCounter >= carouselImages.length - 1) return;
//   carouselSlide.style.transition = 'transform 400ms';
//   imageCounter++;
//   carouselSlide.style.transform = `translateX(-${100 * imageCounter}%)`;
// }

// function slideBack() {
//   // first limit counter to prevent fast-change bugs
//   if (imageCounter <= 0) return;
//   carouselSlide.style.transition = 'transform 400ms';
//   imageCounter--;
//   carouselSlide.style.transform = `translateX(-${100 * imageCounter}%)`;
// }

// function makeLoop() {
//   // instantly move from clones to originals to produce 'infinite-loop' effect
//   if (carouselImages[imageCounter].classList.contains('last-clone')) {
//     carouselSlide.style.transition = 'none';
//     imageCounter = carouselImages.length - 2;
//     carouselSlide.style.transform = `translateX(-${100 * imageCounter}%)`;
//   }

//   if (carouselImages[imageCounter].classList.contains('first-clone')) {
//     carouselSlide.style.transition = 'none';
//     imageCounter = carouselImages.length - imageCounter;
//     carouselSlide.style.transform = `translateX(-${100 * imageCounter}%)`;
//   }
// }

// function goToImage(e) {
//   carouselSlide.style.transition = 'transform 400ms';
//   imageCounter = 1 + navDots.indexOf(e.target);
//   carouselSlide.style.transform = `translateX(-${100 * imageCounter}%)`;
// }

// function highlightCurrentDot() {
//   navDots.forEach((dot) => {
//     if (navDots.indexOf(dot) === imageCounter - 1) {
//       dot.classList.add('active-dot');
//     } else {
//       dot.classList.remove('active-dot');
//     }
//   });
// }

// function addBtnListeners() {
//   nextBtn.addEventListener('click', slideForward);
//   prevBtn.addEventListener('click', slideBack);
// }

// function addNavDotListeners() {
//   navDots.forEach((dot) => {
//     dot.addEventListener('click', goToImage);
//   });
// }

// function addTransitionListener() {
//   carouselSlide.addEventListener('transitionend', () => {
//     makeLoop();
//     highlightCurrentDot();
//   });
// }

// function autoAdvance() {
//   let play = setInterval(slideForward, 5000);

//   carouselFrame.addEventListener('mouseover', () => {
//     clearInterval(play); // pause when mouse enters carousel
//   });

//   carouselFrame.addEventListener('mouseout', () => {
//     play = setInterval(slideForward, 5000); // resume when mouse leaves carousel
//   });

//   document.addEventListener('visibilitychange', () => {
//     if (document.hidden) {
//       clearInterval(play); // pause when user leaves page
//     } else {
//       play = setInterval(slideForward, 5000); // resume when user returns to page
//     }
//   });
// }

// function buildCarousel() {
//   initializeCarousel();
//   initializeNavDots();
//   addNavDotListeners();
//   addBtnListeners();
//   addTransitionListener();
//   autoAdvance();
// }

// buildCarousel();

// particles

var canvas = document.getElementById('canvas');
var ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
var HEIGHT = canvas.height;
var WIDTH = canvas.width;
/*  window.addEventListener("resize", function(){
  WIDTH = canvas.width = window.innerWidth;
  HEIGHT = canvas.height = window.innerHeight;
});*/
function getMousePos(canvas, evt) {
  var rect = canvas.getBoundingClientRect();
  return {
    x: (evt.clientX - rect.left) / (rect.right - rect.left) * canvas.width,
    y: (evt.clientY - rect.top) / (rect.bottom - rect.top) * canvas.height

  };
}

var mousePosX = WIDTH / 2;
var mousePosY = HEIGHT / 2;

canvas.addEventListener('mousemove', function(evt) {
  var mousePos = getMousePos(canvas, evt);
  mousePosX = mousePos.x;
  mousePosY = mousePos.y;
}, false);

function colorRect(leftX, topY, width, height, drawColor) {
  ctx.fillStyle = 'white';
  ctx.fillRect(leftX, topY, width, height);
}

function overLay() {
  var grd = ctx.createRadialGradient(mousePosX, mousePosY, 0, mousePosX, mousePosY, 300);
  grd.addColorStop(0, "rgba(255,255,255,0)");
  grd.addColorStop(1, "rgba(255,255,255,1)");
  ctx.fillStyle = grd;
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
}
var numPoints = WIDTH/10; 
var pointList = {};
var createPointxx = function(name) {
  var pointxx = {
    x: Math.random() * WIDTH,
    y: Math.random() * HEIGHT,
    vx: 1 - Math.random() * 2,
    vy: 1 - Math.random() * 2,
    name: name,
    radius: 2 + Math.random() * 3,
    drawPoint: function() {
      ctx.fillStyle = '#b0dcff';
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2, true);
      ctx.fill();
    }
  };
  pointList[name] = pointxx;
};

var drawLine = function(pointName, pointName2) {
  var distance = 120;

  var dx = pointName.x - pointName2.x;
  var dy = pointName.y - pointName2.y;
  var distance2 = Math.sqrt(dx * dx + dy * dy);

  if (distance2 < distance) {
    var alpha = 1;
    ctx.beginPath();
    ctx.strokeStyle = "rgba(176, 220, 255," + alpha + ")";
    ctx.lineWidth = 1;
    ctx.moveTo(pointName2.x, pointName2.y);
    ctx.lineTo(pointName.x, pointName.y);
    ctx.stroke();
  }
};

var move = function(pointName) {
  pointName.x += pointName.vx;
  pointName.y += pointName.vy;
  if (pointName.x + pointName.radius > WIDTH || pointName.x - pointName.radius < 0) {
    pointName.vx = -pointName.vx;
  }
  if (pointName.y + pointName.radius > HEIGHT || pointName.y - pointName.radius < 0) {
    pointName.vy = -pointName.vy;
  }
  pointName.drawPoint();

};

var connectParticles = function() {
  for (i = 0; i < numPoints; i++) {
    for (t = 0; t < numPoints; t++) {
      if (i != t && i < t) {
        drawLine(pointList["ball" + t], pointList["ball" + i]);
      }
    }
  }
};

var update = function() {
  colorRect(0, 0, WIDTH, HEIGHT, 'black');
  for (var key in pointList) {
    move(pointList[key]);
  }
  connectParticles();
  overLay();
};
for (x = 0; x < numPoints; x++) {
  var name = "ball" + x;
  createPointxx(name);
}
setInterval(update, 20);
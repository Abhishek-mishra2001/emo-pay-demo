const loginText = document.querySelector(".title-text .login");
const loginForm = document.querySelector("form.login");
const loginBtn = document.querySelector("label.login");
const signupBtn = document.querySelector("label.signup");
const signupLink = document.querySelector("form .signup-link a");
signupBtn.onclick = () => {
  loginForm.style.marginLeft = "-50%";
  loginText.style.marginLeft = "-50%";
};
loginBtn.onclick = () => {
  loginForm.style.marginLeft = "0%";
  loginText.style.marginLeft = "0%";
};
signupLink.onclick = () => {
  signupBtn.click();
  return false;
};
function disableSubmit() {
  document.getElementById("submit").disabled = true;
}

function activateButton(element) {
  if (element.checked) {
    document.getElementById("submit").disabled = false;
  } else {
    document.getElementById("submit").disabled = true;
  }
}

var canvas = document.getElementById('canvas');
var ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
var HEIGHT = canvas.height;
var WIDTH = canvas.width;
//   window.addEventListener("resize", function(){
// WIDTH = canvas.width = window.innerWidth;
// HEIGHT = canvas.height = window.innerHeight;
// })
function getMousePos(canvas, evt) {
var rect = canvas.getBoundingClientRect();
return {
  x: (evt.clientX - rect.left) / (rect.right - rect.left) * canvas.width,
  y: (evt.clientY - rect.top) / (rect.bottom - rect.top) * canvas.height

};
}

var mousePosX = WIDTH / 2;
var mousePosY = HEIGHT / 2;

canvas.addEventListener('mousemove', function(evt) {
var mousePos = getMousePos(canvas, evt);
mousePosX = mousePos.x;
mousePosY = mousePos.y;
}, false);

function colorRect(leftX, topY, width, height, drawColor) {
ctx.fillStyle = 'white';
ctx.fillRect(leftX, topY, width, height);
}

function overLay() {
var grd = ctx.createRadialGradient(mousePosX, mousePosY, 0, mousePosX, mousePosY,0 );
grd.addColorStop(0, "rgba(255,255,255,0)");
grd.addColorStop(1, "rgba(255,255,255,1)");
ctx.fillStyle = grd;
ctx.fillRect(0, 0, WIDTH, HEIGHT);
}
var numPoints = WIDTH/25; 
var pointList = {};
var createPointxx = function(name) {
var pointxx = {
  x: Math.random() * WIDTH,
  y: Math.random() * HEIGHT,
  vx: 1 - Math.random() * 2,
  vy: 1 - Math.random() * 2,
  name: name,
  radius: 2 + Math.random() * 2,
  drawPoint: function() {
    ctx.fillStyle = 'rgba(47,228,228,0.2)';
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2, true);
    ctx.fill();
  }
};
pointList[name] = pointxx;
};

var drawLine = function(pointName, pointName2) {
var distance = 120;

var dx = pointName.x - pointName2.x;
var dy = pointName.y - pointName2.y;
var distance2 = Math.sqrt(dx * dx + dy * dy);

if (distance2 < distance) {
  var alpha = 1;
  ctx.beginPath();
  ctx.strokeStyle = "rgba(47,228,228,0.2" + alpha + ")";
  ctx.lineWidth = 1;
  ctx.moveTo(pointName2.x, pointName2.y);
  ctx.lineTo(pointName.x, pointName.y);
  ctx.stroke();
}
};

var move = function(pointName) {
pointName.x += pointName.vx;
pointName.y += pointName.vy;
if (pointName.x + pointName.radius > WIDTH || pointName.x - pointName.radius < 0) {
  pointName.vx = -pointName.vx;
}
if (pointName.y + pointName.radius > HEIGHT || pointName.y - pointName.radius < 0) {
  pointName.vy = -pointName.vy;
}
pointName.drawPoint();

};

var connectParticles = function() {
for (let i = 0; i < numPoints; i++) {
  for (let t = 0; t < numPoints; t++) {
    if (i != t && i < t) {
      drawLine(pointList["ball" + t], pointList["ball" + i]);
    }
  }
}
};

var update = function() {
colorRect(0, 0, WIDTH, HEIGHT, 'black');
for (var key in pointList) {
  move(pointList[key]);
}
connectParticles();
overLay();
};
for (let x = 0; x < numPoints; x++) {
var name = "ball" + x;
createPointxx(name);
}
setInterval(update, 20);

import CommonWrapper from "./common-wrapper"
import CommonMainComponent from "./common-children"
function CommonPart({name}) {
    return (
        <>
        <CommonMainComponent>
        <div className="card-body">
        <CommonWrapper name={name}/>
        </div>
        </CommonMainComponent>
        </>
    )
}
export default CommonPart;
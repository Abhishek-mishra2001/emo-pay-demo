function CommonComponents({name}) {
    return (
        <>
            <div className="card-body">
                <h4 className="card-title">{name.cardTitle}</h4>
                <form className="forms-sample">
                    <div className="form-group row">
                        <div className="col-sm-12">
                            <input
                                type="text"
                                className="form-control"
                                id={name.id}
                                placeholder={name.placeholder}
                            />
                        </div>
                    </div>
                    <button type="submit" className="btn btn-primary mr-2">
                    {name.btnFirst}
                    </button>
                    <button className="btn btn-light">{name.btnSecond}</button>
                </form>
            </div>
        </>
    )
}
export default CommonComponents;
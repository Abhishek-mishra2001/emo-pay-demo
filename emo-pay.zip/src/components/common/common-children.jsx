import HeaderProfile from "../admin/admin-layout/header-profile";
import SideBar from "../admin/admin-layout/sidebar";
import FooterProfile from "../admin/admin-layout/footer-profile";
function CommonMainComponent({children,status}){
    return(
        <>
        <div className="container-scroller">
                <HeaderProfile />
                <div className="container-fluid page-body-wrapper">
                    <SideBar />
                    <div className="main-panel">
                        <div className="content-wrapper">
                            <div className={status==true ?`col-12 grid-margin stretch-card`:'col-12 grid-margin'}>
                                <div className="card">
                                    {children}
                                </div>
                            </div>
                        </div>
                        <FooterProfile />
                    </div>
                </div>
            </div>
        </>
    )
}
export default CommonMainComponent;
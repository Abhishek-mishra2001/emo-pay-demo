function CommonTable({name}) {
    return (
        <>
            <table className="table table-borderless">
                <thead>
                    <tr>
                        {
                            name.map((item,index)=>{
                                const borderClass = index === 0 ? 'pl-0  pb-2 border-bottom' :'border-bottom pb-2';
                                return(
                                    <th key={index} className={borderClass}>{item}</th>
                                ) 
                            })
                        }
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td className="pl-0" />
                        <td className="text-muted" />
                        <td className="text-muted" />
                        <td className="text-muted" />
                        <td className="text-muted" />
                        <td className="text-muted" />
                    </tr>
                </tbody>
            </table>
        </>
    )
}
export default CommonTable;
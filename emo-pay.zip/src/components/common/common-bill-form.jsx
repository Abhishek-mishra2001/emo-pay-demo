import CommonMainComponent from "./common-children";
import FormGroupSelect from "./common-form-select";
import FormInfoGroup from "../admin/profile/form-info-group";
function CommonBillForm({title,billPay,btn,status,formInfo,formSelect,avaliableEmo,extraBtn,invalid}){
    return(
        <CommonMainComponent status={status}>
            <div className="card-body">
                    <h4 className="card-title">{title}</h4>
                    <form className="forms-sample">
                    {invalid==true ?<p className="card-description" style={{ color: "#0060ac" }}>Invalid ID</p> :''}
                      <h3>
                        {avaliableEmo}
                        <font style={{ color: "#0060ac" }}>
                          <b>{billPay}</b>
                        </font>
                      </h3>
                      {formSelect.map((item,index)=><FormGroupSelect key={index} name={item} />)}
                      {formInfo.map((item,index)=><FormInfoGroup key={index} name={item} />)}
                      <button type="submit" className="btn btn-primary mr-2">
                       {btn}
                      </button>
                      {extraBtn &&  <button className="btn btn-light">{extraBtn}</button>}
                     
                    </form>
                  </div>
        </CommonMainComponent>
    )
}
export default CommonBillForm;
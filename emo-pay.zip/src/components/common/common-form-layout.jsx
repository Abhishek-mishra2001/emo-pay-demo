import CommonForm from "./common-form";
import CommonMainComponent from "./common-children";
function CommonFormLayout({name}) {
    return (
        <>
        <CommonMainComponent>
        <CommonForm name={name} />
        </CommonMainComponent>
        </>
    )
}
export default CommonFormLayout;
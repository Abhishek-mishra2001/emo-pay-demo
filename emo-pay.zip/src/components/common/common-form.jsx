function CommonForm({name}){
    return(
        <>
        <div className="card-body">
              <h4 className="card-title">{name}</h4>
              <form className="forms-sample">
                <div className="form-group">
                  <label htmlFor="exampleOldInputPassword1">Old Password</label>
                  <input
                    type="password"
                    className="form-control"
                    id="exampleOldInputPassword1"
                    placeholder="Password"
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="exampleNewInputPassword1">New Password</label>
                  <input
                    type="password"
                    className="form-control"
                    id="exampleNewInputPassword1"
                    placeholder="Password"
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="exampleInputConfirmPassword1">
                    Confirm Password
                  </label>
                  <input
                    type="password"
                    className="form-control"
                    id="exampleInputConfirmPassword1"
                    placeholder="Password"
                  />
                </div>
                <button type="submit" className="btn btn-primary mr-2">
                  Update
                </button>
                <button className="btn btn-light">Reset</button>
              </form>
            </div>
        </>
    )
}
export default CommonForm;
import CommonTable from "./common-table";
function CommonWrapper({ name }) {
    return (
        <>
            <button type="submit" className="btn btn-primary mr-2">
                Copy
            </button>
            <button type="submit" className="btn btn-primary mr-2">
                CSV
            </button>
            <button type="submit" className="btn btn-primary mr-2">
                Excel
            </button>
            <button type="submit" className="btn btn-primary mr-2">
                PDF
            </button>
            <button type="submit" className="btn btn-primary mr-2">
                Print
            </button>
            <br />
            <br />
            <div className="row">
                <div className="col-md-12 stretch-card grid-margin">
                    <div className="card">
                        <div className="card-body">
                            <p className="card-title mb-0">My Investment</p>
                            <div className="table-responsive">
                                <CommonTable name={name} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
export default CommonWrapper;
function FormGroupSelect({name}) {
    const selectData = name.selectOpt;
    return (
        <div className="form-group row">
            <label htmlFor=" " className="col-sm-3 col-form-label">
                {name.label}
            </label>
            <div className="col-sm-9">
                <select className="form-control">
                    {selectData.map((item,index)=><option key={index} value={item.val}>{item.title}</option>)}
                </select>
            </div>
        </div>
    )
}
export default FormGroupSelect;
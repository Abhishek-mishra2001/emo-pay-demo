function StretchCard({name,count,status}) {
    return (
        <>
            <div className={status==true ? `col-md-4 mb-4 stretch-card transparent` :`col-md-3 mb-4 stretch-card transparent`}>
                <div className="card card-dark-blue">
                    <div className="card-body">
                        <p className="mb-4">{name}</p>
                        <p className="fs-30 mb-2">{count}</p>
                    </div>
                </div>
            </div>
        </>
    )
}
export default StretchCard;
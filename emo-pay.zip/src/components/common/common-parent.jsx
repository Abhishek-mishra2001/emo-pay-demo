import CommonComponents from "./common-components";
import CommonMainComponent from "./common-children";
function CommonParent({name}){
    return(
        <>
        <CommonMainComponent>
        <CommonComponents name={name}/>
        </CommonMainComponent>
        </>
    )
}

export default CommonParent;
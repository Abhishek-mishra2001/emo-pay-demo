function SelectOption({name}) {
    const arr = name.selectOpt;
    return (
        <>
            <div className="col-md-12">
                <div className="form-group row">
                    <div className="col-md-12">
                        <div className="form-group row">
                            <label className="col-sm-3 col-form-label">
                               {name.label}
                            </label>
                            <div className="col-sm-9">
                                <select className="form-control">
                                    {arr.map((item,index)=><option key={index}>{item}</option>)}
                                    
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
export default SelectOption;
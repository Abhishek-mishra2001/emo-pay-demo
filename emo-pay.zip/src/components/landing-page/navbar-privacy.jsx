import logo from '../../assets/landing-page-assets/images/logo.svg';
function NavBarPrivacy() {
    return (
        <>
            <nav
                id="navbarExample"
                className="navbar navbar-expand-lg fixed-top navbar-light"
                aria-label="Main navigation"
            >
                <div className="container">
                    <a className="navbar-brand logo-image" href="index.html">
                        <img src={logo} alt="alternative" />
                    </a>
                    <button
                        className="navbar-toggler p-0 border-0"
                        type="button"
                        id="navbarSideCollapse"
                        aria-label="Toggle navigation"
                    >
                        <span className="navbar-toggler-icon" />
                    </button>
                    <div
                        className="navbar-collapse offcanvas-collapse"
                        id="navbarsExampleDefault"
                    >
                    </div>
                </div>
            </nav>
        </>
    )
}
export default NavBarPrivacy;
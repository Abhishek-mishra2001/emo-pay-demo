function EmoPrice() {
    return (
        <>
            <div className="basic-3" id="emoprice" style={{ paddingTop: 100 }}>
                <div className="container">
                    <div className="text-center">
                        <h2 className="h2-large">EMO Price</h2>
                        <h1 className="h1-large">1 EMO = $ 0.0084</h1>
                    </div>
                </div>
            </div>
        </>
    )
}
export default EmoPrice;
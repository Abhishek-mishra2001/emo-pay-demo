import uparrow from '../../assets/landing-page-assets/images/up-arrow.png';
function Copyright(){
    return(
        <>
        <div className="copyright">
    <div className="container">
      <div className="row">
        <div className="">
          <p className="p-small">
            Copyright ©
            <a href="https://www.emopay.org" target="_blank">
              EmoPay
            </a>
            All Rights Reserved
          </p>
        </div>
        {/* end of col */}
        <div className="col-lg-6">
          <p className="p-small" />
        </div>
        {/* end of col */}
      </div>
      {/* enf of row */}
    </div>
    {/* end of container */}
  </div>
  <button  id="myBtn">
    <img src={uparrow} alt="alternative" />
  </button>
        </>
    )
}
export default Copyright;
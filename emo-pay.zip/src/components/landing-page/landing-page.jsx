import LandingPageFooter from "./footer";
import LandingPageHeader from "./header";
import LandingPageNav from "./navbar";
import emoverse from '../../assets/landing-page-assets/images/emoverse.png';
import download from '../../assets/landing-page-assets/images/download.png';
import banking1 from '../../assets/landing-page-assets/images/banking1.png';
import recharge from '../../assets/landing-page-assets/images/recharge.png';
import buynsell from '../../assets/landing-page-assets/images/buy&sell.png';
import charity from '../../assets/landing-page-assets/images/charity.png';
import EmoPrice from "./emo-price";
import EmoVerseSlider from "./emo-verse-slider";
import Copyright from "./copyright";
function LandingPage() {
    return (
            <>
            <LandingPageNav/>
            <LandingPageHeader/>
                <EmoPrice/>
                <EmoVerseSlider/>
                <div id="emoverse" className="basic-1 bg-gray">
                    <div className="container">
                        <div className="row box">
                            <div className="col-lg-7">
                                <div className="text-container">
                                    <h1 className="h1-large">EMOVerse</h1>
                                    <h4 className="h4-large">
                                        <b>EMO Building a Practical &amp; Sustainable Ecosystem</b>
                                    </h4>
                                    <br />
                                    <p>
                                        Emo Development Team is working on creating the EMO usability
                                        ecosystem, which is called EMOVerse. EMOVerse empowers the
                                        ecosystem to be a sustainable financial ecosystem. This will allow
                                        all EMOians to use this ecosystem in their daily lives as a
                                        financial solution.
                                        <br />
                                        <br />
                                        EMOians can use EMO in their daily lives, similar to the fiat
                                        financial system.
                                        <br />
                                        <br />
                                        EMOVerse will empower EMOians to:
                                        <br />
                                        <br />
                                    </p>
                                </div>
                            </div>
                            <div className="col-lg-5">
                                <div className="image-container">
                                    <img
                                        className="img-fluid"
                                        src={emoverse}
                                        style={{ width: 550 }}
                                        alt="emoverse"
                                    />
                                </div>
                            </div>
                            <div className="row" style={{ marginTop: 30 }}>
                                <div className="col-lg-6">
                                    1. Pay and Receive Payments
                                    <br />
                                    2. Grow their Assets with Staking
                                    <br />
                                    3. Recharge, Bill Payments, and Bookings
                                    <br />
                                    4. Pay in-store and online
                                    <br />
                                    5. Buy and Sell EMO
                                    <br />
                                </div>
                                <div className="col-lg-6">
                                    6. Play Games Online
                                    <br />
                                    7. Donate EMO for Charity
                                    <br />
                                    8. Create Valuations of their assets through EMOSWAP
                                    <br />
                                    9. Own Properties through EMOValley
                                    <br />
                                    <br />
                                </div>
                            </div>
                            <br />
                            <a
                                href="https://play.google.com/store/apps/details?id=org.emopay"
                                target="_blank"
                            >
                                <img
                                    src={download}
                                    style={{ paddingTop: 15, width: 200 }}
                                    alt="download"
                                />
                            </a>
                        </div>
                    </div>
                    <div className="container">
                        <div className="row box">
                            <div className="col-lg-5" style={{ paddingTop: 40, paddingRight: 40 }}>
                                <div className="image-container">
                                    <img
                                        className="img-fluid"
                                        src={banking1}
                                        style={{ width: 550 }}
                                        alt="banking"
                                    />
                                </div>
                            </div>
                            <div className="col-lg-7">
                                <div className="text-container" style={{ paddingBottom: 70 }}>
                                    <h1 className="h1-large">Staking</h1>
                                    <h4 className="h4-large">
                                        <b>Safe and Secure for the Scale and Growth of Assets</b>
                                    </h4>
                                    <br />
                                    <p>
                                        The EMO Staking Programme is a magnificent way to Earn Passive
                                        Income for an individual. Once you purchase EMO, instead of
                                        holding it in your wallets, Stake or Freeze your EMO as per the
                                        desired tenure.
                                        <br />
                                        This will not only help every stakeholder earn extra rewards as
                                        EMO for themselves, but they will also be helping the Community by
                                        getting a new supply of EMO into the Market. EMO Staking is simple
                                        and accessible to everyone. Anyone can start the staking process
                                        with a minimum of 500 EMO. The user can select the tenure from 1
                                        year to 5 years and earn APY (Annual Per Yield) as per the tenure.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="container" id="pricing">
                        <div className="row box">
                            <div className="">
                                <div className="text-center" style={{ paddingTop: 30 }}>
                                    <h1 className="h1-large">Fastest Way to Pay &amp; Receive EMO’s</h1>
                                    <p>
                                        Pay &amp; Receive payments from anyone, anywhere, and anytime.
                                        <br />
                                        Pay for secure payments to in-store or online using your EMO
                                        Wallet.
                                    </p>
                                    <br />
                                    <a
                                        href="https://play.google.com/store/apps/details?id=org.emopay"
                                        target="_blank"
                                    >
                                        <img
                                            src={download}
                                            style={{ paddingTop: 75, width: 200 }}
                                            alt="download"
                                        />
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="container">
                        <div className="row box">
                            <div className="col-lg-5">
                                <div className="image-container">
                                    <img
                                        className="img-fluid"
                                        src={recharge}
                                        style={{ width: 350 }}
                                        alt="recharge"
                                    />
                                </div>
                            </div>
                            <div className="col-lg-7">
                                <div className="text-container">
                                    <h1 className="h1-large">Recharge, Bill Payment, &amp; Bookings</h1>
                                    <p>
                                        First crypto currency in the World which allows you to Pay
                                        Postpaid Bills, Recharge Mobile &amp; DTH. You can book your
                                        flights, hotels, movie tickets, Recharge metro cards, and much
                                        more with your EMOs.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="container">
                        <div className="row box">
                            <div className="col-lg-7">
                                <div className="text-container">
                                    <h1 className="h1-large">Buy and Sell EMO</h1>
                                    <p>
                                        EMOPAY is working to provide the best possible decentralised
                                        solution for its users. We are trying to automate the process so
                                        that Buying and Selling EMO doesn’t require any extra support.
                                        <br />
                                        <br />
                                        Now you can Buy EMO with USDT.
                                        <br />
                                        Debit card/ Credit card facilities are coming soon.
                                    </p>
                                    <br />
                                    <br />
                                    <br />
                                    <br />
                                    User can sell their EMOs by placing bids and convert their EMOs into
                                    USDT or local fiat currency.
                                </div>
                            </div>
                            <div className="col-lg-5">
                                <div className="image-container">
                                    <img
                                        className="img-fluid"
                                        src={buynsell}
                                        style={{ width: 550 }}
                                        alt="buy&sell"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="container">
                        <div className="row box">
                            <div className="col-lg-5">
                                <div className="image-container">
                                    <img
                                        className="img-fluid"
                                        src={charity}
                                        style={{ width: 350, paddingTop: 30 }}
                                        alt="charity"
                                    />
                                </div>
                            </div>
                            <div className="col-lg-7">
                                <div className="text-container">
                                    <br />
                                    <h1 className="h1-large">EMO Charity</h1>
                                    <p>
                                        Not only Creating the Technology for the future, EMOPAY also
                                        believes in helping and raising the weaker sections of society and
                                        bringing happiness to their faces.
                                        <br />
                                        <br />
                                        EMOians can donate their EMOs for this welfare cause so that these
                                        funds can be used for the following:
                                        <br />
                                        1. Serving Foods
                                        <br />
                                        2. Donating Clothes
                                        <br />
                                        3. Education
                                        <br />
                                        4. Healthcare
                                    </p>
                                    <br />
                                    <br />
                                    <br />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <LandingPageFooter/>
                <Copyright/>
            </>
    )
}
export default LandingPage;
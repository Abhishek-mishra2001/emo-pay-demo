import { sliderData } from "../store/data/slider-data";
function EmoVerseSlider() {
    return (
            <div className="basic-3">
                <div className="container">
                    <div className="row">
                        <section className="customer-logos slider">
                            {sliderData.map((item, index) => <div className="slide" key={index}><img src={item.imgSrc} alt={item.imgAlt} /><p>{item.imgTitle}</p></div>)}
                        </section>
                    </div>
                </div>
            </div>
    )
}
export default EmoVerseSlider;
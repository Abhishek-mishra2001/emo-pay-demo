import logo from '../../assets/landing-page-assets/images/logo.svg';
import Copyright from './copyright';
import LandingPageFooter from './footer';
import NavBarPrivacy from './navbar-privacy';
import PrivacyHeader from './privacy-header';
function Terms(){
    return(
        <>
 <NavBarPrivacy/>
 <PrivacyHeader name="Staking - Terms and Conditions"/>
  <div className="ex-basic-1 pt-5 pb-5">
    <div className="container">
      <div className="row">
        <div className="col-xl-10 offset-xl-1">
          <p className="mb-3">
            When using any of the
            <b>
              <a href="https://www.emopay.org" target="_blank">
                www.emopay.org
              </a>
            </b>
            services, the buyer is agreeing to the following conditions in full:
            For the purpose of these terms,
            <b>
              <a href="https://www.emopay.org" target="_blank">
                emopay.org
              </a>
            </b>
            will be referred to as the “Operator” and all users of the company’s
            services shall be referred to as the “Buyer”.
          </p>
          <h2 className="mt-5">1. Risk Notice</h2>
          <p className="mb-3">
            When purchasing an EMO Staking Contract through the website, the
            buyer agrees that he or she is 15 years of age." "The buyer must
            check his or her local jurisdiction laws applicable before buying
            the EMO Staking Contract and only purchase if he or she is allowed
            to do so.&nbsp;When purchasing an EMO staking contract, the customer
            assumes all risks. The company or operator makes absolutely no
            guarantee about the future value of the EMO purchased or its
            earnings.
            <br />
            <br />
            <b>Customer Input Errors:</b> It is the sole responsibility of the
            customer or buyer to check the correctness of the information
            entered and saved on the website. Account details displayed on the
            order summary webpage will be the final transfer destination. In the
            event that this information is incorrect and funds are transferred
            to an unintended destination, the company shall not reimburse,
            refund, or compensate the customer and shall not transfer additional
            funds. As such, customers must ensure that the EMO wallet address or
            any other required information they enter is absolutely correct.
          </p>
          <h2 className="mt-5">2. Definitions</h2>
          <p className="mb-3">
            Cryptocurrency is a peer-to-peer payment system and digital currency
            that uses cryptography to control the creation and transfer of
            money. An EMO Staking Contract is a contract for a package where the
            buyer earns returns in the form of cryptocurrency. The staking
            contract period is 360 days, 720 days, 1080 days, and 1800 days from
            the date of purchase of the EMO contract, unless otherwise agreed in
            writing between the operator and the buyer.
          </p>
          <p className="mb-3">
            The buyer is the purchaser of an EMO Staking Contract through the
            website, also referred to as "user" or "you."
          </p>
          <p className="mb-3">
            Operator is the owner or company that owns &amp; operates the
            website
            <b>
              <a href="https://www.emopay.org" target="_blank">
                www.emopay.org
              </a>
            </b>
            . Contract Purchase Date is the date the buyer submits the request
            to purchase the EMO Staking Contract via the online form at the
            website, unless otherwise agreed in writing between the operator and
            the buyer.
          </p>
          <p className="mb-3">
            Contract Purchase Date is the date the buyer submits the request to
            purchase the EMO Staking Contract via the online form at the
            website, unless otherwise agreed in writing between the operator and
            the buyer.
          </p>
          <p className="mb-3">
            A transaction is an agreement between the buyer and the operator to
            purchase an EMO staking contract at an agreed rate.
          </p>
          <p className="mb-3">
            Price means the price at which the buyer agrees to purchase an Emo
            Staking Contract. The transaction price is the total price
            comprising the price payable to the operator for an EMO staking
            contract.
          </p>
          <h2 className="mt-5">3. Personal Account</h2>
          <p>
            In order to purchase an EMO staking contract on
            <b>
              <a href="https://www.emopay.org" target="_blank">
                www.emopay.org
              </a>
            </b>
            the user has to create a personal account or ID with the operator,
            providing his or her name, email address, and phone number. Creating
            a personal account or ID is free of charge; however, you have to
            acknowledge the terms and conditions. Your username cannot be
            changed. The user must ensure that the username and password are
            always kept confidential. In the event of misuse or abuse, the
            operator reserves the right to disable your personal account. The
            operator will record the amount of EMO earned on the buyer’s staking
            contract in the buyer’s personal account from time to time. While
            the Operator will use its best efforts to ensure such records are
            accurate and up-to-date, the Operator makes no guarantee as to the
            accuracy of any such records and reserves the absolute right at its
            sole discretion to vary, correct, or alter such records, and the
            Buyer has no absolute right to the amount of EMO recorded on the
            Buyer’s personal account from time to time.
          </p>
          <h2 className="mt-5">4. Purchase of EMO Staking Contract</h2>
          <p>
            <b>
              <a href="https://www.emopay.org" target="_blank">
                www.emopay.org
              </a>
            </b>
            offers the EMO Staking Contract. The buyer accepts the package price
            offered by the operator upon submitting a valid purchase request via
            the online form at the website. By submitting such a purchase
            request, an online payment will be processed, and the transaction is
            binding upon you. Please make sure that all your data is correct.
            Also, you are responsible for ensuring that your email communication
            is safe and protected against third-party access.
            <br />
            The buyer agrees to pay the operator the package price as per the
            table below.
          </p>
          <h2 className="mt-5">4.1 Withdrawal Request</h2>
          <p>
            The operator will transfer the requested currency earned to the
            buyer’s designated cryptocurrency wallet upon request. The buyer
            agrees that the operator will not make any such transfers, despite
            any request to do so..
          </p>
          <h2 className="mt-5">5. Emopay Services</h2>
          <p>
            By purchasing an Emo Staking Contract on our website, you
            acknowledge and agree that: cryptocurrencies are not recognised as
            legal tender in certain countries, are not regulated by any central
            institution, and may be subject to extreme price volatility; The
            Buyer understands the risks involved with digital currencies
            included in cryptocurrency; the Buyer is responsible for protecting
            your cryptocurrency, cryptocurrency wallet, computer software, bank
            account, address, and personal data against any theft, fraud, or
            illegal activity; and the Operator does not accept any
            responsibility for any loss or damage suffered by you or any of your
            authorised agents or representatives in connection with an EMO
            Staking Contract, whether directly or indirectly, and including
            where you provide the Operator with any false information.
            <br />
            <br />
            All concluded transactions are irreversible; The Operator is not
            responsible for Cryptocurrency transfers made to any incorrect
            Cryptocurrency wallet IDs and The Buyer and your agents agree to
            release The Operator from all loss or damage suffered in connection
            with such Cryptocurrency transfers whether directly or indirectly;
            The Buyer has obtained independent legal and financial advice about
            the risks associated with buying Cryptocurrency, or knowingly and
            voluntarily elected not to do so; The Operator has the right to
            refuse any order for any reason, which is at the absolute discretion
            of the Operator and the Buyer hereby agree to release and indemnify
            the Operator in the exercise of that discretion. The buyer further
            acknowledges that trading currency, including cryptocurrency,
            involves risk, especially through price fluctuation. In addition,
            there might be unforeseen risks that are not identified in these
            T&amp;Cs. The operator cannot be held liable for any consequences of
            such unforeseen risks.
          </p>
          <h2 className="mt-5">6. Intellectual Property and Linking</h2>
          <p>
            The operator and the licensors own all intellectual property rights
            on this and affiliated websites.
            <br />
            <b>
              <a href="https://www.emopay.org" target="_blank">
                www.emopay.org
              </a>
            </b>
            has not reviewed all of the sites linked to the website and is not
            responsible for the contents of any such linked site. The inclusion
            of any link does not imply endorsement by our company of the site.
            Use of any such linked website is at the buyer's or user’s own risk.
          </p>
          <h2 className="mt-5">7. User obligation</h2>
          <p>
            The buyer warrants that he or she will only use the website in
            accordance with the purpose of the offered service and solely based
            on the T&amp;Cs. The buyer further agrees that he or she has the
            authority and means to enter into a transaction. Furthermore, the
            buyer warrants that he or she is the legitimate owner of the
            monetary sums he or she intends to exchange against the EMO Staking
            Contract and that he or she does not infringe the rights of any
            third party or applicable law. In addition, the buyer agrees not to
            use the website or the EMO Staking Contract, whether directly or
            indirectly, for any kind of illegal activity such as money
            laundering, terrorism financing, or negatively affecting the
            performance of the website. It is prohibited to use or copy any of
            the information or contents of this or affiliated websites. It is
            prohibited to send spam or distribute any other material through the
            website. It is prohibited to distribute any illegal material through
            the website or use the website in any other way than intended by the
            operators. The buyer or user must not collect any data from this
            website or its users without prior written permission from the
            operator. The buyer or user must not use anonymous networks such as
            TOR to access our website. Any misuse of the operator’s services
            based on these T&amp;Cs will result in the seizure of the EMO
            Staking Contract and any relevant funds.
          </p>
          <h2 className="mt-5">8. Liability</h2>
          <p className="mb-3">
            <b>
              <a href="https://www.emopay.org" target="_blank">
                www.emopay.org
              </a>
            </b>
            does not offer any legal, financial, insurance, tax, investment, or
            associated advice. All transactions are the sole responsibility of
            the buyer, considering his or her personal circumstances. The
            operator does not recommend anything available on the website.
            <br />
            <br />
            <b>
              <a href="https://www.emopay.org" target="_blank">
                www.emopay.org
              </a>
            </b>
            is not responsible for any loss suffered by the buyer or user. In no
            event shall
            <b>
              <a href="https://www.emopay.org" target="_blank">
                www.emopay.org
              </a>
            </b>
            or its people be liable for any damages (including, without
            limitation, damages (for loss of data or profit or due to business
            interruption) arising out of the use or inability to use the
            website, or any part of it, or an EMO Staking Contract, even if
            <b>
              <a href="https://www.emopay.org" target="_blank">
                www.emopay.org
              </a>
            </b>
            or an authorised representative has been notified orally or in
            writing of the possibility of such damage. Because some
            jurisdictions do not allow limitations on implied warranties or
            limitations of liability for consequential or incidental damages,
            these limitations may not apply to the buyer. In the event that
            applicable law does not allow the limitation or exclusion of
            liability or incidental or consequential damages, the operator’s
            liability will be limited to the fullest extent permitted by
            applicable law. Without limiting the previous paragraph and except
            as required by the Operator, the Operator will not be liable(
            including in negligence) for any loss of profits, loss of revenue,
            or any direct, indirect, or consequential loss or damage incurred by
            or awarded against the Buyer or any other person arising directly or
            indirectly from your use of the website or purchase of an EMO
            Staking Contract, or for any cost, loss, liability, or expense
            arising from death, personal injury, or damage to property resulting
            directly or indirectly from the Buyer’s use of the service,
            including the purchase of an EMO Staking Contract. Furthermore, the
            operator cannot be held liable for any malfunction, breakdown,
            delay, or interruption to the internet connection, or if, for any
            reason, our website is unavailable at any time or for any period.
            The operator also cannot be held liable for any incorrect
            information from third parties displayed on our website. In the case
            of fraud, the operator will report all necessary information,
            including names, addresses, and all other requested information, to
            the relevant authorities dealing with fraud and breaches of law.
          </p>
          <h2 className="mt-5">9. Security</h2>
          <p className="mb-3">
            The buyer or user is responsible for maintaining the confidentiality
            and integrity of their cryptocurrency wallet, including its access
            information. The buyer must notify the operator if the wallet
            address has changed or if there is any other change, loss, or
            suspicion about the buyer’s cryptocurrency wallet or any transfers
            in or out of it. The operator will not be held liable for any lost
            cryptocurrency wallet information or hacked cryptocurrency wallet
            accounts, nor for any loss arising as a result, including theft or
            fraud. The operator closely observes any activities that might
            relate to money laundering or illegal activities. The operator
            reserves the right to share user information with third parties to
            ensure the intended operation of the website and its security.
            <br />
            <br />
            <b>
              <a href="https://www.emopay.org" target="_blank">
                www.emopay.org
              </a>
            </b>
            is not liable for any damage incurred as a result of sending emails
            through the Internet. Emails should only be sent in encrypted
            format.
          </p>
          <h2 className="mt-5">10. Money Laundering Prevention</h2>
          <p className="mb-3">
            <b>
              <a href="https://www.emopay.org" target="_blank">
                www.emopay.org
              </a>
            </b>
            might ask the buyer to confirm their identity or other personal
            details before the transfer of cryptocurrency to your wallet. This
            does not mean in any way that suspicion is falling on the buyer, and
            any information about the buyer’s identity is held confidentially.
            The operator is also required to keep full records of all
            transactions and cryptocurrency transfers, together with the
            identification provided, and constantly monitor any unusual or
            suspicious transactions of any size.
          </p>
          <h2 className="mt-5">11. Amendment, assignment and governing law</h2>
          <p className="mb-3">
            The operator can assign its various rights under this agreement to
            any other person without asking your permission. The buyer’s rights
            are personal and not assignable. The laws of the state of Estonia
            govern these terms and conditions without regard to its conflict of
            law provisions, and the buyer irrevocably and unconditionally
            submits to the non-exclusive jurisdiction of the courts of Estonia
            to resolve any dispute that arises as a result of or in connection
            with this agreement. These T&amp;C are to be interpreted so that
            they comply with all applicable laws, and if any provision does not
            comply, then it must be read down so as to give it as much effect as
            possible. If it is not possible to give that provision any effect at
            all, then it is to be severed from this agreement, in which case the
            remainder of this agreement will continue to have full force and
            effect. These T&amp;C and our Privacy Policy are the entire
            agreement between the parties as to their subject matter and
            supersede all prior or inconsistent statements or representations as
            to that subject matter.
          </p>
          <h2 className="mt-5">12. Termination or suspension</h2>
          <p className="mb-3">
            These terms may be modified or terminated by the operator without
            reason at any point in time, but with prior notice. However, the
            operator may immediately terminate this agreement if the buyer or
            user breaches any of the clauses mentioned in our terms and
            conditions. In addition, the operator reserves the right to take
            legal action against the buyer or user and suspend access to the
            website and related services. Therefore, the operator may block
            computers using the user's IP address from accessing our website. In
            addition, the operator may contact your internet service provider
            and take such measures as to block you from accessing our website
            and services. In addition, the operator may take legal action
            against the buyer and recover the costs from the buyer. Especially
            if the buyer tries to use the website for illegal activities,
            violates any of these terms, fails to pay for the buyer’s
            transaction, or commits any fraud related to that. The operator also
            reserves the right to cancel transactions that are not paid for or
            confirmed. The operator can stop supplying any service at any time
            without notice to the buyer, and the operator reserves the right to
            refuse to supply the service to any person for any reason,
            especially if the user registers or submits a purchase under false
            identity or with the wrong personal information, including an email
            address, interferes with any of the company’s operations, or uses
            language that we consider unacceptable, including vulgar, racist,
            sexual, or offensive language. No refunds are provided if the buyer
            or user decides to terminate the contract.
          </p>
          <h2 className="mt-5">13. Disclaimer</h2>
          <p className="mb-3">
            The materials on the operator’s website are provided "as is."
            <b>
              <a href="https://www.emopay.org" target="_blank">
                www.emopay.org
              </a>
            </b>
            makes no warranties, expressed or implied, and hereby disclaims and
            negates all other warranties, including, without limitation, implied
            warranties or conditions of merchantability, fitness for a
            particular purpose, non-infringement of intellectual property, or
            other violations of rights. Further, the operator does not warrant
            or make any representation concerning the accuracy, likely results,
            or reliability of the use of the materials on our website or
            otherwise relating to such materials on any sites linked to this
            website. The materials appearing on
            <b>
              <a href="https://www.emopay.org" target="_blank">
                www.emopay.org
              </a>
            </b>
            could include technical, typographical, or photographic errors. The
            operator may make changes to the materials contained on its website
            at any time without notice. The operator does not, however, make any
            commitment to update the materials. Please contact us if you have
            questions or are not satisfied with anything. E-mail:
            <b>
              <a href="mailto:support@emopay.org">support@emopay.org</a>
            </b>
          </p>
        </div>
      </div>
    </div>
  </div>
  <LandingPageFooter/>
  <Copyright/>
</>

    )
}
export default Terms;
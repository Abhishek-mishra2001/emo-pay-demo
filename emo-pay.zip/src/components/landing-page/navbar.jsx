import logo from '../../assets/landing-page-assets/images/logo.png';
import { NavLink } from 'react-router-dom';
function LandingPageNav() {
    return (
        <>
            <div data-bs-spy="scroll" data-bs-target="#navbarExample">
                <nav id="navbarExample" className="navbar navbar-expand-lg fixed-top navbar-light top-nav-collapse" aria-label="Main navigation">
                    <div className="container">
                        <NavLink className="navbar-brand logo-image" to="/landing-page"><img src={logo} alt="Emopay Logo" /></NavLink>
                        <button
                            className="navbar-toggler p-0 border-0"
                            type="button"
                            id="navbarSideCollapse"
                            aria-label="Toggle navigation"
                        >
                            <span className="navbar-toggler-icon" />
                        </button>
                        <div
                            className="navbar-collapse offcanvas-collapse"
                            id="navbarsExampleDefault"
                        >
                            <ul className="navbar-nav ms-auto navbar-nav-scroll">
                                <li className="nav-item">
                                    <a className="nav-link active" aria-current="page" href="#header">
                                        Home
                                    </a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#emoprice">
                                        EMO Price
                                    </a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#emoverse">
                                        EMOVerse
                                    </a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#pricing">
                                        Services
                                    </a>
                                </li>
                                <li className="nav-item">
                                    <a
                                        className="nav-link"
                                        href="https://www.emonews.digital"
                                        target="_blank"
                                    >
                                        EMO News
                                    </a>
                                </li>
                            </ul>
                            <span className="nav-item">
                                <NavLink className="btn-outline-sm" to="/login">
                                 Log in
                                </NavLink>
                            </span>
                        </div>
                    </div>
                </nav>
            </div>
        </>
    )
}
export default LandingPageNav;
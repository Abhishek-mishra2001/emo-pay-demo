import banner from '../../assets/landing-page-assets/images/banner.png';
import { NavLink } from 'react-router-dom';
function LandingPageHeader(){
    return(
        <>
        <header id="landing-header" className="landing-header">
                    <div className="container">
                        <div className="row">
                            <div className="col-lg-6">
                                <div className="text-container">
                                    <h1 className="h1-large">EmoPay<br /><span className="replace-me">One World, One Wallet, One Currency</span></h1>
                                    <h3 className='h3-large'>World's Most Secure Decentralised Payment Platform</h3>
                                    <br />
                                    <NavLink className="btn-solid-reg" to="/login">SignUp</NavLink>
                                    <NavLink className="btn-solid-reg" to="/login">LogIn</NavLink>
                                </div>
                            </div>
                            <div className="col-lg-6">
                                <div className="image-container">
                                    <img
                                        className="img-fluid"
                                        src={banner}
                                        style={{ width: 550 }}
                                        alt="Emopay Banner"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </header>
        </>
    )
}
export default LandingPageHeader
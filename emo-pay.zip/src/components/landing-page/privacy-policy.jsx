import Copyright from "./copyright";
import LandingPageFooter from "./footer";
import NavBarPrivacy from "./navbar-privacy";
import PrivacyHeader from "./privacy-header";
function PrivacyPolicy(){
    return(
        <>
  <NavBarPrivacy/>
  <PrivacyHeader name="Privacy Policy"/>
  <div className="ex-basic-1 pt-5 pb-5">
    <div className="container">
      <div className="row">
        <div className="col-xl-10 offset-xl-1">
          <h2 className="mt-5 mb-3">
            Websites may use the privacy policy given below:
          </h2>
          <p className="mb-3">
            The terms "we," "us," "our," and "company" individually and
            collectively refer to EMOPay, and the terms "you," "your," and
            "yourself" refer to the users.
          </p>
          <p className="mb-3">
            This Privacy Policy is an electronic record in the form of an
            electronic contract formed under the Information Technology Act,
            2000, the rules made thereunder, and the amended provisions
            pertaining to electronic documents and records in various statutes
            as amended by the Information Technology Act, 2000. This privacy
            policy does not require a physical, electronic, or digital
            signature.
          </p>
          <p className="mb-3">
            This privacy policy is a legally binding document between you and
            EmoPay (both terms are defined below). The terms of this Privacy
            Policy will be effective upon your acceptance of them (directly or
            indirectly in electronic form, by clicking on the I accept tab, by
            use of the website, or by other means) and will govern the
            relationship between you and Emopay for your use of the website
            ("Website") (defined below).
          </p>
          <p className="mb-3">
            This document is published and shall be construed in accordance with
            the provisions of the 2011 Information Technology (reasonable
            security practises and procedures and sensitive personal data and
            information) Rules under the Information Technology Act, 2000, which
            require the publication of the Privacy Policy for the collection,
            use, storage, and transfer of sensitive personal data and
            information.
            <br />
            Please read this privacy policy carefully. By using the website, you
            indicate that you understand, agree with, and consent to this
            privacy policy. If you do not agree with the terms of this privacy
            policy, please do not use this website.
          </p>
          <p className="mb-3">
            By providing us with your information or by making use of the
            facilities provided by the website, you hereby consent to the
            collection, storage, processing, and transfer of any or all of your
            personal and non-personal information by us as specified under this
            privacy policy. You further agree that such collection, use,
            storage, and transfer of your information shall not cause any loss
            or wrongful gain to you or any other person.
          </p>
          <h2 className="mt-5">User Information</h2>
          <p className="mb-3">
            To avail of certain services on our websites, users are required to
            provide certain information for the registration process, namely: a)
            their name; b) their email address; c) their mobile number; and d)
            their password. The information supplied by the users enables us to
            improve our sites, and we will provide you with the most
            user-friendly experience.
            <br />
            <br />
            All required information is service-dependent, and we may use the
            above-mentioned user information to maintain, protect, and improve
            its services (including advertising services) and to develop new
            services.
          </p>
          <p className="mb-3">
            Such information will not be considered sensitive if it is freely
            available and accessible in the public domain or is furnished under
            the Right to Information Act, 2005, or any other law for the time
            being in force.
          </p>
          <h2 className="mt-5">Cookies</h2>
          <p className="mb-3">
            To improve the responsiveness of the sites for our users, we may use
            "cookies", or similar electronic tools to collect information to
            assign each visitor a unique, random number as a User Identification
            (User ID) to understand the user's individual interests using the
            identified computer. Unless you voluntarily identify yourself
            (through registration, for example), we will have no way of knowing
            who you are, even if we assign a cookie to your computer. The only
            personal information a cookie can contain is the information you
            supply. A cookie cannot read data off your hard drive.
          </p>
          <p className="mb-3">
            Our web servers automatically collect limited information about your
            computer's connection to the Internet, including your IP address,
            when you visit our site. (Your IP address is a number that lets
            computers attached to the Internet know where to send you data, such
            as the web pages you view.) Your IP address does not identify you
            personally.
            <br />
            We use this information to deliver our web pages to you upon
            request, to tailor our site to the interests of our users, to
            measure traffic within our site, and to let advertisers know the
            geographic locations from which our visitors come.
          </p>
          <h2 className="mt-5">Links to the other sites</h2>
          <ul className="list-unstyled li-space-lg mb-4">
            <li className="d-flex">
              <i className="fas fa-square" />
              <div className="flex-grow-1">
                Our policy discloses the privacy practises for our own website
                only.
              </div>
            </li>
            <li className="d-flex">
              <i className="fas fa-square" />
              <div className="flex-grow-1">
                Our site also provides links to other websites that are beyond
                our control. We will in no way be responsible for your use of
                such sites.
              </div>
            </li>
          </ul>
          <h2 className="mt-5">Information Sharing</h2>
          <p className="mb-3">
            We share sensitive personal information with any third party without
            obtaining the prior consent of the user in the following limited
            circumstances:
          </p>
          <ul className="list-unstyled li-space-lg mb-4">
            <li className="d-flex">
              <i className="fas fa-square" />
              <div className="flex-grow-1">
                <strong>(a)</strong> When it is requested or required by law or
                by any court, governmental agency, or authority to disclose, for
                the purpose of verification of identity, prevention, detection,
                investigation, including cyber incidents, or prosecution and
                punishment of offences. These disclosures are made in good faith
                and in the belief that such disclosure is reasonably necessary
                for enforcing these Terms and complying with the applicable laws
                and regulations.
              </div>
            </li>
            <li className="d-flex">
              <i className="fas fa-square" />
              <div className="flex-grow-1">
                <strong>(b)</strong> We propose to share such information within
                its group companies and with officers and employees of such
                group companies for the purpose of processing personal
                information on its behalf. We also ensure that these recipients
                of such information agree to process such information based on
                our instructions and in compliance with this privacy policy and
                any other appropriate confidentiality and security measures.
              </div>
            </li>
          </ul>
          <h2 className="mt-5">Information Security</h2>
          <ul className="list-unstyled li-space-lg mb-4">
            <li className="d-flex">
              <i className="fas fa-square" />
              <div className="flex-grow-1">
                We take appropriate security measures to protect against
                unauthorized access to or unauthorized alteration, disclosure or
                destruction of data. These include internal reviews of our data
                collection, storage and processing practices and security
                measures, including appropriate encryption and physical security
                measures to guard against unauthorized access to systems where
                we store personal data.
              </div>
            </li>
            <li className="d-flex">
              <i className="fas fa-square" />
              <div className="flex-grow-1">
                All information gathered on our website is securely stored
                within our controlled database. The database is stored on
                servers secured behind a firewall; access to the servers is
                password-protected and strictly limited. However, as effective
                as our security measures are, no security system is
                impenetrable. We cannot guarantee the security of our database,
                nor can we guarantee that the information you supply will not be
                intercepted while being transmitted to us over the Internet.
                And, of course, any information you include in a posting to the
                discussion areas is available to anyone with Internet access.
              </div>
            </li>
            <li className="d-flex">
              <i className="fas fa-square" />
              <div className="flex-grow-1">
                However, the internet is an ever-evolving medium. We may change
                our privacy policy from time to time to incorporate necessary
                future changes. Of course, our use of any information we gather
                will always be consistent with the policy under which the
                information was collected, regardless of what the new policy may
                be.
              </div>
            </li>
            <li className="d-flex">
              <i className="fas fa-square" />
              <div className="flex-grow-1">
                Grievance Redressal Mechanism: Any complaints, abuse, or
                concerns with regard to content, comment, or breach of these
                terms shall be immediately informed to the designated Grievance
                Officer as mentioned below, either in writing or through email
                signed with an electronic signature to
                <b>
                  <a href="mailto:support@emopay.org"> support@emopay.org</a>
                </b>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <LandingPageFooter/>
  <Copyright/>
</>

    )
}
export default PrivacyPolicy;
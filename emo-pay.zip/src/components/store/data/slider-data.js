import emovalley from '../../../assets/landing-page-assets/images/emovalley.svg';
import exchange from '../../../assets/landing-page-assets/images/exchange.svg';
import swap from '../../../assets/landing-page-assets/images/swap.svg';
import nft from '../../../assets/landing-page-assets/images/nft.svg';
import staking from '../../../assets/landing-page-assets/images/staking.svg';
import hotel from '../../../assets/landing-page-assets/images/hotel.svg';
import bus from '../../../assets/landing-page-assets/images/bus.svg';
import flight from '../../../assets/landing-page-assets/images/flight.svg';
import insurance from '../../../assets/landing-page-assets/images/insurance.svg';
import phone from '../../../assets/landing-page-assets/images/phone.svg';
import shop from '../../../assets/landing-page-assets/images/shop.svg';
import game from '../../../assets/landing-page-assets/images/game.svg';
import service from '../../../assets/landing-page-assets/images/service.svg';
import bank from '../../../assets/landing-page-assets/images/bank.svg';
import donation from '../../../assets/landing-page-assets/images/donation.svg';
import dth from '../../../assets/landing-page-assets/images/dth.svg';
import electricity from '../../../assets/landing-page-assets/images/electricity.svg';
import water from '../../../assets/landing-page-assets/images/water.svg';
const sliderData = [
    {imgSrc:emovalley,imgAlt:'emovalley',imgTitle:'EmoValley'},
    {imgSrc:exchange,imgAlt:'exchange',imgTitle:'Exchange'},
    {imgSrc:swap,imgAlt:'swap',imgTitle:'Swap'},
    {imgSrc:nft,imgAlt:'nft',imgTitle:'NFT Marketplace'},
    {imgSrc:staking,imgAlt:'staking',imgTitle:'Staking'},
    {imgSrc:hotel,imgAlt:'hotel',imgTitle:'Hotel Booking'},
    {imgSrc:bus,imgAlt:'bus',imgTitle:'Bus Booking'},
    {imgSrc:flight,imgAlt:'flight',imgTitle:'Flight Booking'},
    {imgSrc:insurance,imgAlt:'insurance',imgTitle:'Insurance'},
    {imgSrc:phone,imgAlt:'phone',imgTitle:'Mobile Recharge'},
    {imgSrc:shop,imgAlt:'shop',imgTitle:'Shopping'},
    {imgSrc:game,imgAlt:'game',imgTitle:'Games'},
    {imgSrc:service,imgAlt:'service',imgTitle:'Services'},
    {imgSrc:bank,imgAlt:'bank',imgTitle:'Loan'},
    {imgSrc:donation,imgAlt:'donation',imgTitle:'Donation'},
    {imgSrc:dth,imgAlt:'dth',imgTitle:'DTH Recharge'},
    {imgSrc:electricity,imgAlt:'electricity',imgTitle:'Electricity Payment'},
    {imgSrc:water,imgAlt:'water',imgTitle:'Water Bill'},

]
export {sliderData};
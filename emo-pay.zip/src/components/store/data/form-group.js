export const formGroup = {
    obj1:{id:'exampleInputUsername2',label:'Full Name',type:'text',placeholder:'Username'},
    obj2:{id:'exampleInputEmail2',label:'Email',type:'email',placeholder:'Email'},
    obj3:{id:'exampleInputMobile',label:'Mobile',type:'text',placeholder:'Mobile number'},
    obj4:{id:'address',label:'Address',type:'text',placeholder:''},
    obj5:{cardTitle:'CURRENT WALLET ADDRESS',id:'current-wallet',btnFirst:'Submit', btnSecond:'Cancel', placeholder:''},
    obj6:{cardTitle:'Emo Deposite Gateway',id:'',btnFirst:'Proceed to pay', btnSecond:'Reset', placeholder:'Enter Emo'},
    obj7:{id:'',label:'Member Code',type:'text',placeholder:'Enter ID No.'},
    obj8:{id:'',label:'Transfer Amount',type:'text',placeholder:''},
    obj9:{label:'To Wallet',selectOpt:[
        {val:'emo Wallet',title:'Emo Wallet'}]},
    obj10:{label:'Select Wallet',selectOpt:[
        {val:'emo Wallet',title:'Emo Wallet'}]},
    obj11:{id:'recharge-no',label:'Mobile No.',type:'text',placeholder:'Recharge No'},
    obj12:{id:'amount',label:'Amount',type:'text',placeholder:'Amount'},
    obj13:{label:'Country',selectOpt:[
        {val:'Package-540 Days-8% Monthly',title:'India'},
        {val:'Package-360 Days-7% Monthly',title:'America'},
        {val:'Package-270 Days-6% Monthly',title:'Russia'},
        {val:'Package-180 Days-5% Monthly',title:'China'}]},
    obj14:{label:'Circle',selectOpt:[
            {val:'Package-540 Days-8% Monthly',title:'Delhi'},
            {val:'Package-360 Days-7% Monthly',title:'Mumbai'},
            {val:'Package-270 Days-6% Monthly',title:'Gujrat'},
            {val:'Package-180 Days-5% Monthly',title:'Andaman &amp; Nicobar'}]},
    obj15:{label:'Provider',selectOpt:[
                {val:'Package-540 Days-8% Monthly',title:'Airtel'},
                {val:'Package-360 Days-7% Monthly',title:'VI'},
                {val:'Package-270 Days-6% Monthly',title:'Jio'},
            ]},
    obj16:{label:'Provider',selectOpt:[
                {val:'Package-540 Days-8% Monthly',title:'Ajmer Vidyut Vitran Nigam - RAJASTHAN'},
                {val:'Package-270 Days-6% Monthly',title:'APDCL (Non-RAPDR) - ASSAM'},
            ]},
    obj17:{id:'k-number',label:'K Number',type:'text',placeholder:'K Number'},
    obj18:{label:'Provider',selectOpt:[
        {val:'Package-540 Days-8% Monthly',title:'Airtel Digital DTH'},
        {val:'Package-270 Days-6% Monthly',title:'Jio Digital DTH'},
    ]},
    obj19:{id:'customer-id',label:'Customer ID',type:'text',placeholder:'Recharge No'},
    obj20:{id:'id-no',label:'ID NO.',type:'text',placeholder:''},
    obj21:{id:'emo-amount',label:'Enter EMO',type:'text',placeholder:''},
    obj22:{label:'Select Days',selectOpt:[
        {val:'Package-540 Days-8% Monthly',title:'Package-540 Days-8% Monthly'},
        {val:'Package-360 Days-7% Monthly',title:'Package-360 Days-7% Monthly'},
        {val:'Package-270 Days-6% Monthly',title:'Package-270 Days-6% Monthly'},
        {val:'Package-180 Days-5% Monthly',title:'Package-180 Days-5% Monthly'},
    ]},
    
}
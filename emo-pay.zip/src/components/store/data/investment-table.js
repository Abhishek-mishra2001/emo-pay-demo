export const investmentTable = {
    investTable:['S.No.','Staking','Date','Maturity Date','Remaining Days','Staked EMO','Maturity Action'],
    directEmonians:['S.No.','User Name','Member Name','DOJ','Total Token','Total Team Token','Mobile No','Email'],
    teamLevelEmo:['S.No.','Select','Level','Directs','Total Token'],
    dailyIncome:['S.No.','Date','Staking Returns','Level Income','Net EMO'],
    dailyStakeReturn:['S.No.','Date','Package','Percent(%)','Staking Returns'],
    withdrawal:['S.No.','Request Date','EMO','Request Status','Transfer Date','Transaction Detail','Account Address','TxLD'],
    transactions:['S.No.','Remarks','Debit','Credit','Date']
}
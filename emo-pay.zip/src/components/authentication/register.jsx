import { contryListShort } from "../store/data/country-list"
import { useForm } from "react-hook-form";
function Register() {
    const { register, handleSubmit, formState: { errors } } = useForm();
    const onSubmit = (data) => {
        console.log(data)
    }
    return (
        <form className="signup" onSubmit={handleSubmit(onSubmit)}>
            <div className="field">
                <input type="text" {...register('sponser_id', {
                    required: 'This is required', minLength: {
                        value: 5, message: "Min. Length is 5"
                    }
                })} aria-invalid={errors.sponser_id ? "true" : "false"} placeholder="Sponser ID" />
            </div>
            <p style={{ color: 'red' }}>{errors.sponser_id?.message}</p>
            <div className="field">
                <input type="text" {...register('sponser_name', {
                    required: 'This is required', minLength: {
                        value: 5, message: 'Min. Length is 5'
                    }
                })} aria-invalid={errors.sponser_name ? "true" : "false"} placeholder="Sponser Name" />
            </div>
            <p style={{ color: 'red' }}>{errors.sponser_name?.message}</p>
            <div className="field">
                <input type="text" {...register('username', {
                    required: 'This is required', minLength: {
                        value: 5, message: "Min. Length is 5"
                    }
                })} placeholder="Your Name" />
            </div>
            <p style={{ color: 'red' }}>{errors.username?.message}</p>
            <div className="field">
                <input type="text" {...register('mobile_no', {
                    required: 'This is required', minLength: {
                        value: 10, message: "Min. Length is 10"
                    }, pattern: {
                        value: /^(\+|\d)[0-9]{7,16}$/, message: 'Please fill correct Mobile No.'
                    }
                })} placeholder="Mobile No. with country code" />
            </div>
            <p style={{ color: 'red' }}>{errors.mobile_no?.message}</p>
            <div className="field">
                <input type="text" {...register('email', {
                    required: 'This is required', pattern: {
                        value: /^\S+@\S+\.\S+$/, message: "Please fill correct email address"
                    }
                })} placeholder="Email Address" required="" />
            </div>
            <p style={{ color: 'red' }}>{errors.email?.message}</p>
            <div className="field">
                <select id="country" {...register('country', { required: 'This is required' })}>
                    {contryListShort.map((item, index) => <option key={index} value={item.countryVal}>{item.countryName}</option>)}
                </select>
            </div>
            <p style={{ color: 'red' }}>{errors.country?.message}</p>
            <br />
            <input type="checkbox" {...register('terms', { required: 'This is required' })} id="terms" /> I Agree
            <a href="">Terms &amp; Coditions</a>
            <p style={{ color: 'red' }}>{errors.terms?.message}</p>
            <div className="field">
                <div className="btn-layer" />
                <input type="submit" value="Signup" />
            </div>
        </form>
    )
}
export default Register;
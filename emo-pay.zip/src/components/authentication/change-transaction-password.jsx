import CommonFormLayout from "../common/common-form-layout";
function ChangeTransactionPassword(){
    return(
        <>
        <CommonFormLayout name="Change Transaction Password" />
        </>
    )
}
export default ChangeTransactionPassword;
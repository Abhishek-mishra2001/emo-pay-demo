import CommonFormLayout from "../common/common-form-layout";
function ChangePassword() {
    return (
        <>
        <CommonFormLayout name="Change Password" />
        </>
    )
}
export default ChangePassword;
import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
function Login() {
    const { register, handleSubmit, formState: { errors } } = useForm();
    const navigate = useNavigate();
    const onSubmit = (data) => {
        console.log(data)

    }
    // const handleSubmit = (e)=>{
    //     e.preventDefault();
    //     navigate('/dashboard')
    // }
    return (
        <form action="#" onSubmit={handleSubmit(onSubmit)} className="login">
            <div className="field">
                <input type="text" {...register('email', {
                    required: 'This is required', pattern: {
                        value: /^\S+@\S+\.\S+$/, message: "Please fill correct email address"
                    }
                })} aria-invalid={errors.email ? "true" : "false"} placeholder="Email/User ID" />
            </div>
            <p style={{ color: 'red' }}>{errors.email?.message}</p>
            <div className="field">
                <input type="password" {...register('password', {
                    required: 'This is required', pattern: {
                        value: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$@!%&*?])[A-Za-z\d#$@!%&*?]{8,30}$/, message: "Please fill correct password"
                    }
                })} aria-invalid={errors.password ? "true" : "false"} placeholder="Password" />
            </div>
            <p style={{ color: 'red' }}>{errors.password?.message}</p>
            <div className="pass-link">
                <a href="#">Forgot password?</a>
            </div>
            <div className="field">
                <div className="btn-layer" />
                <input type="submit" value="Login" />
            </div>
            <div className="signup-link">
                Not a member? <a href="">Signup now</a>
            </div>
        </form>
    )
}
export default Login;
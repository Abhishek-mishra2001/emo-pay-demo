import logo from '../../assets/images/logo.png';
import signup from '../../assets/images/sign-up.svg';
import Canvas from "./canvas";
import Register from './register';
import Login from './login';
function Layout() {
    return (
        <>
         <Canvas/>
            <div className="container login">
                <div className="row">
                    <div className="col-md-6" style={{ paddingTop: 20 }}>
                        <img src={logo} style={{ width: 250 }} />
                        <img src={signup} />
                    </div>
                    <div className="col-md-6" style={{ paddingTop: 10 }}>
                        <div className="wrapper">
                            <h5>
                                <span>
                                    <b>One</b>
                                </span>
                                <div className="message">
                                    <div className="word1">World</div>
                                    <div className="word2">Wallet</div>
                                    <div className="word3">Currency</div>
                                </div>
                            </h5>
                            <div className="form-container">
                                <div className="slide-controls">
                                    <input type="radio" name="slide" id="login" defaultChecked="" />
                                    <input type="radio" name="slide" id="signup" />
                                    <label htmlFor="login" className="slide login">
                                        Login
                                    </label>
                                    <label htmlFor="signup" className="slide signup">
                                        Signup
                                    </label>
                                    <div className="slider-tab" />
                                </div>
                                <div className="form-inner">
                                   <Login/>
                                   <Register/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
export default Layout;

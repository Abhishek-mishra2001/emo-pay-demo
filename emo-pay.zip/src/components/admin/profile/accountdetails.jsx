import { formGroup } from "../../store/data/form-group";
import FormInfoGroup from "./form-info-group";
import { countryListLong } from "../../store/data/country-list";
import CommonMainComponent from "../../common/common-children";
function Accountdetails(){
    return(
        <>
        <CommonMainComponent>
        <div className="card-body">
              <h4 className="card-title">Personal Information</h4>
              <form className="forms-sample">
                <FormInfoGroup name={formGroup.obj1} />
                <FormInfoGroup name={formGroup.obj2} />
                <FormInfoGroup name={formGroup.obj3} />
                <div className="form-group row">
                  <label className="col-sm-3 col-form-label">Country</label>
                  <div className="col-sm-9">
                    <select className="form-control">
                      {countryListLong.map((item,index)=><option key={index} value={item.countryVal}>{item.countryName}</option>)}
                    </select>
                  </div>
                </div>
                <FormInfoGroup name={formGroup.obj4} />
                <button type="submit" className="btn btn-primary mr-2">
                  Update
                </button>
                <button className="btn btn-light">Reset</button>
              </form>
            </div>
        </CommonMainComponent>
        </>
    )
}
export default Accountdetails;
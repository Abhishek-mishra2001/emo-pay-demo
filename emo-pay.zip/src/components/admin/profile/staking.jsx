import CommonMainComponent from "../../common/common-children";
import StretchCard from "../../common/stretch-card";
import FooterProfile from "../admin-layout/footer-profile";
import HeaderProfile from "../admin-layout/header-profile";
import SideBar from "../admin-layout/sidebar";
import RefferalStretchCard from "./refferal-stretchcard";

function Staking(){
    return(
        <div className="container-scroller">
        <HeaderProfile/>
        <div className="container-fluid page-body-wrapper">
          <SideBar/>
          <div className="main-panel">
            <div className="content-wrapper">
              <div className="row">
                <div className="col-md-12 grid-margin">
                  <div className="row">
                    <div className="col-12 col-xl-8 mb-4 mb-xl-0">
                      <h2 className="font-weight-bold">Hello! Manish Welcome back</h2>
                    </div>
                  </div>
                </div>
              </div>
              <div className="row">
                <RefferalStretchCard/>
                <div className="col-md-6 grid-margin transparent">
                  <div className="row">
                    <StretchCard name="DIRECT EMOIAN" count="4006" status={true} />
                    <StretchCard name="INDIRECT EMOIAN" count="61344" status={true} />
                    <StretchCard name="TOTAL EMOIANS" count="61344" status={true} />
                  </div>
                  <div className="row">
                  <StretchCard name="DIRECT STAKING" count="4006" status={true} />
                  <StretchCard name="DOWNLINE STAKING" count="61344" status={true}/>
                  <StretchCard name="TOTAL STAKING" count="61344"status={true} />
                  </div>
                </div>
              </div>
              <hr />
              <h2 className="font-weight-bold">Investments &amp; Returns</h2>
              <br />
              <div className="col-md-12 grid-margin transparent">
                <div className="row">
                    <StretchCard name="DIRECT EMOIAN" count="61344"/>
                    <StretchCard name="INDIRECT EMOIAN" count="61344"/>
                    <StretchCard name="TOTAL EMOIANS" count="61344"/>
                </div>
              </div>
            </div>
            <FooterProfile/>
          </div>
        </div>
      </div>
      
    )
}
export default Staking;
import CommonPart from "../../common/common-part";
import { investmentTable } from "../../store/data/investment-table";
function TeamLevelEmonians(){
    return(
        <>
        <CommonPart name={investmentTable.teamLevelEmo} />
        </>
    )
}
export default TeamLevelEmonians;
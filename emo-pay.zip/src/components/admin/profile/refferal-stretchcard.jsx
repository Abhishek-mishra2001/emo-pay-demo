function RefferalStretchCard(){
    return(
        <div className="col-md-6 grid-margin stretch-card">
                  <div className="card  card-body tale-bg card-body text-center">
                    <br />
                    <h3>Invite Referral Link</h3>
                    <br />
                    <input
                      type="text"
                      defaultValue="https://www.emopay.org/joinnow.aspx?url=UmVmZm9ybW5vPTk5MjM2OTQzNDg="
                      id="myInput"
                    />
                    <br />
                    <button
                      type="button"
                      className="btn btn-primary btn-rounded btn-fw"
                      // onClick="myFunction()"
                    >
                      Copy text
                    </button>
                    <br />
                    <a
                      href="https://api.whatsapp.com/send?phone=whatsappphonenumber&text=https://www.emopay.org/joinnow.aspx?url=UmVmZm9ybW5vPTk5MjM2OTQzNDg="
                      target="_blank"
                    >
                      <font style={{ fontWeight: 900, fontSize: 25 }}>Whatsapp</font>
                    </a>
                  </div>
                </div>
    )
}
export default RefferalStretchCard;
import { formGroup } from "../../store/data/form-group";
import CommonBillForm from "../../common/common-bill-form";
function MobileRecharge(){
    const formSelect = [formGroup.obj13,formGroup.obj14,formGroup.obj15];
    const formInfo = [formGroup.obj11,formGroup.obj12];
    return(
        <CommonBillForm formInfo={formInfo} formSelect={formSelect} title="Mobile Recharge" billPay="244.26" btn="Proceed To Recharge"  status={true} avaliableEmo="Available EMO:"/>
    )
}
export default MobileRecharge;

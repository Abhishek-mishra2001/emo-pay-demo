function FormInfoGroup({name}) {
    return (
        <>
            <div className="form-group row">
                <label htmlFor={name.id} className="col-sm-3 col-form-label">{name.label}</label>
                <div className="col-sm-9">
                    <input type={name.type} className="form-control" id={name.id} placeholder={name.placeholder}/>
                </div>
            </div>
        </>
    )
}
export default FormInfoGroup;
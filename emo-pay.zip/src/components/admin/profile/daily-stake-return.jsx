import CommonPart from "../../common/common-part";
import { investmentTable } from "../../store/data/investment-table";
function DailyStakeReturn(){
    return(
        <>
        <CommonPart name={investmentTable.dailyStakeReturn}/>
        </>
    )
}
export default DailyStakeReturn;
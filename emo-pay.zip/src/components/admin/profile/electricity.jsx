import { formGroup } from "../../store/data/form-group";
import CommonBillForm from "../../common/common-bill-form";
function Eletricity(){
  const formSelect = [formGroup.obj13,formGroup.obj14,formGroup.obj16];
  const formInfo = [formGroup.obj17,formGroup.obj12];
    return(
      <CommonBillForm formInfo={formInfo} formSelect={formSelect} title="Electricity Bill" billPay="244.26" btn="Proceed To Pay"  status={true} avaliableEmo="Available EMO:"/>
    )
}
export default Eletricity;
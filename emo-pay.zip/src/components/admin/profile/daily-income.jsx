import CommonPart from "../../common/common-part";
import { investmentTable } from "../../store/data/investment-table";
function DailyIncome(){
    return(
        <>
        <CommonPart name={investmentTable.dailyIncome}/>
        </>
    )
}
export default DailyIncome;
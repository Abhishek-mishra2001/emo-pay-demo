import CommonParent from "../../common/common-parent"
import { formGroup } from "../../store/data/form-group";
function DepositeEmo(){
    return(
        <>
        <CommonParent name={formGroup.obj6} />
        </>
    )
}
export default DepositeEmo;
import { formGroup } from "../../store/data/form-group";
import CommonBillForm from "../../common/common-bill-form";
function Buypackage(){
  const formSelect = [formGroup.obj22];
  const formInfo = [formGroup.obj20,formGroup.obj21];
    return(
        <>
        <CommonBillForm formInfo={formInfo} formSelect={formSelect} title="Upgrade Package" billPay="244.26" btn="Stake"  status={true} avaliableEmo="Available EMO:" extraBtn="Cancel" />
        </>
    )
}
export default Buypackage;
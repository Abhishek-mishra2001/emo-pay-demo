import CommonPart from "../../common/common-part";
import { investmentTable } from "../../store/data/investment-table";
function WithdrawalDetails(){
    return(
        <>
        <CommonPart name={investmentTable.withdrawal}/>
        </>
    )
}
export default WithdrawalDetails;
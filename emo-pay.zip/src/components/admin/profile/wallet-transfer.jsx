import { formGroup } from "../../store/data/form-group";
import CommonBillForm from "../../common/common-bill-form";
function WalletTransfer() {
    const formSelect = [formGroup.obj10,formGroup.obj9];
  const formInfo = [formGroup.obj7,,formGroup.obj8];
    return (
        <>
        <CommonBillForm formInfo={formInfo} formSelect={formSelect} title="Fund Transfer" billPay="244.26" btn="Proceed" invalid={true}  status={true} avaliableEmo="Available Amount :"/>
        </>
    )
}
export default WalletTransfer;
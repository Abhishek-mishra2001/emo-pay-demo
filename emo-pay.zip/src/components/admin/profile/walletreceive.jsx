import CommonMainComponent from "../../common/common-children";
import qr from '../../../assets/images/qr.png';
function WalletRecieve(){
    return(
        <CommonMainComponent>
            <div className="card-body text-center">
                    <h2>Wallet Receive</h2>
                    <br />
                    <form className="form-sample">
                      <div className="row">
                        <div className="col-md-12">
                          <h3>
                            <font style={{ color: "#0060ac" }}>
                              <b>Manish</b>
                            </font>
                          </h3>
                          <h3>
                            <br />
                          </h3>
                        </div>
                        <div className="col-md-12">
                          <img
                            src={qr}
                            style={{ alignContent: "center" }}
                          />
                        </div>
                        <br />
                        <br />
                        <div className="col-md-12 ">
                          ID No.{" "}
                          <input
                            type="text"
                            defaultValue={45684645}
                            id="myInput"
                            style={{ border: "None" }}
                          />
                          <br />
                          <br />
                          <button
                            type="button"
                            className="btn btn-primary btn-rounded btn-fw"
                            // onClick="myFunction()"
                          >
                            Copy
                          </button>
                          {/* <a href="https://wa.me/?text=https://www.emopay.org/joinnow.aspx?url=UmVmZm9ybW5vPTk5MjM2OTQzNDg=">Whatsapp</a>
                           */}
                        </div>
                      </div>
                    </form>
                  </div>
        </CommonMainComponent>
    )
}
export default WalletRecieve;
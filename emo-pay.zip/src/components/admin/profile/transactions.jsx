import CommonPart from "../../common/common-part";
import { investmentTable } from "../../store/data/investment-table";
function TranSactions(){
    return(
        <>
        <CommonPart name={investmentTable.transactions}/>
        </>
    )
}
export default TranSactions;
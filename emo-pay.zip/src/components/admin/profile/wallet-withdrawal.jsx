import WalletTransfer from "./wallet-transfer";
function WalletWithdrawal(){
    return(
        <>
        <WalletTransfer/>
        </>
    )
}
export default WalletWithdrawal;
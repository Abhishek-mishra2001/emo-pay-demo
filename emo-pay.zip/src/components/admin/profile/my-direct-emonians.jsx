import CommonPart from "../../common/common-part";
import { investmentTable } from "../../store/data/investment-table";
function MyDirectEmonians(){
    return(
        <>
        <CommonPart name={investmentTable.directEmonians} />
        </>
    )
}
export default MyDirectEmonians;
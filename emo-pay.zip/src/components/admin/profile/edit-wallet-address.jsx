import CommonParent from "../../common/common-parent";
import { formGroup } from "../../store/data/form-group";
function EditWalletAddress() {

    return (
        <>
          <CommonParent name={formGroup.obj5}/> 
        </>
    )
}
export default EditWalletAddress;
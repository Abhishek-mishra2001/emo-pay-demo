import CommonWrapper from "../../common/common-wrapper";
import FooterProfile from "../admin-layout/footer-profile";
import HeaderProfile from "../admin-layout/header-profile";
import SideBar from "../admin-layout/sidebar";
import { investmentTable } from "../../store/data/investment-table";
import StretchCard from "../../common/stretch-card";
function BlockExplorer() {
    return (
        <>
            <div className="container-scroller">
                <HeaderProfile />
                <div className="container-fluid page-body-wrapper">
                    <SideBar />
                    <div className="main-panel">
                        <div className="content-wrapper">
                            <div className="col-12 grid-margin stretch-card">
                                <div className="card">
                                    <div className="card-body">
                                        <h4 className="card-title">Enter ID For Detail</h4>
                                        <form className="form-inline">
                                            <label className="sr-only" htmlFor="inlineFormInputName2">
                                                Name
                                            </label>
                                            <input
                                                type="text"
                                                className="form-control mb-2 mr-sm-2"
                                                id="inlineFormInputName2"
                                                placeholder=""
                                            />
                                            <button type="submit" className="btn btn-primary mb-2">
                                                Proceed
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-12 grid-margin">
                                    <div className="row">
                                        <div className="col-12 col-xl-8 mb-4 mb-xl-0">
                                            <h2 className="font-weight-bold">EMO Block Explorer</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-12 grid-margin transparent">
                                <div className="row">
                                    <StretchCard name="TOTAL EMOIANS" count="61344"/>
                                    <StretchCard name="TOTAL TRANSACTIONS" count="61344"/>
                                    <StretchCard name="TOTAL EMO STAKED" count="61344"/>
                                    <StretchCard name="WALLET BALANCE" count="61344"/>
                                </div>
                            </div>
                            <hr />
                            <CommonWrapper name={investmentTable.investTable}/>
                        </div>
                       <FooterProfile/>
                    </div>
                    {/* main-panel ends */}
                </div>
                {/* page-body-wrapper ends */}
            </div>

        </>
    )
}
export default BlockExplorer;
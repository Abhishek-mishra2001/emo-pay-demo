import CommonPart from "../../common/common-part";
import { investmentTable } from "../../store/data/investment-table";
function MyInvestment(){
    return(
        <>
        <CommonPart name={investmentTable.investTable}/>
        </>
    )
}
export default MyInvestment;
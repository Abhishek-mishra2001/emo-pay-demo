import { formGroup } from "../../store/data/form-group";
import CommonBillForm from "../../common/common-bill-form";
function Dth(){
    const formSelect = [formGroup.obj13,formGroup.obj14,formGroup.obj18];
  const formInfo = [formGroup.obj19,formGroup.obj12];
    return(
        <CommonBillForm formInfo={formInfo} formSelect={formSelect} title="DTH Recharge" billPay="244.26" btn="Proceed To Recharge"  status={true} avaliableEmo="Available EMO:"/>
    )
}
export default Dth;
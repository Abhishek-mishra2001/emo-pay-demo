import InnerSection from "./innerSection";
function SideBarInnerSection({ name }) {
    const arr = name.innerSection
    return (
        <>
            <li className="nav-item">
                <a className="nav-link" data-toggle="collapse" href={name.sideLink} aria-expanded="false" aria-controls={name.ariaControl}>
                    {name.imgSvg}
                    <span className="menu-title">{name.menuTitle}</span>
                    <i className="menu-arrow" />
                </a>
                <div className="collapse" id={name.ariaControl}>
                    <ul className="nav flex-column sub-menu">
                        {arr.map((item, index) => <InnerSection key={index} name={item.name} pageLink={item.link} />)}
                    </ul>
                </div>
            </li>
        </>
    )
}

export default SideBarInnerSection;
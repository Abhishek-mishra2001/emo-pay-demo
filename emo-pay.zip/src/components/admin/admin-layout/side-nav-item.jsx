import { NavLink } from "react-router-dom";
function SideNavItem({name}){
    return(
        <>
        <li className="nav-item">
          <NavLink className="nav-link" to={name.sideLink}>
            {name.imgSvg}
            &nbsp;
            <span className="menu-title">{name.menuTitle}</span>
          </NavLink>
        </li>
        </>
    )
}
export default SideNavItem;
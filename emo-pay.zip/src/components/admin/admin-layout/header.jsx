import logo from '../../../assets/img/logo.svg';
import wallet2 from '../../../assets/img/wallet2.svg';
import profile from '../../../assets/img/profile.svg';
import message from '../../../assets/img/message.svg';
import setting from '../../../assets/img/setting.svg';
import language from '../../../assets/img/language.svg';
import c from '../../../assets/img/c.png';
import logout from '../../../assets/img/logout.svg';
import flag from '../../../assets/img/flag.svg';
import '../../../assets/css/style.css';
import { NavLink } from 'react-router-dom';
function Header() {
  return (
    <>
      <header id="header" className="fixed-top d-flex align-items-center">
        <div className="container d-flex align-items-center justify-content-between">
          <div className="logo">
            <NavLink to="/landing-page">
              <img src={logo} alt="" />
            </NavLink>
          </div>
          <nav className="navbar">
            <img src={flag} style={{ marginRight: 15 }} />
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width={16}
              height={16}
              fill="currentColor"
              className="bi bi-search"
              viewBox="0 0 16 16"
              style={{ marginRight: 15 }}
            >
              <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
            </svg>
            <ul>
              <li className="dropdown">
                <a className="getstarted scrollto">
                  <span style={{ color: "white" }}>
                    <i className="bx bxs-user" />
                  </span>{" "}
                  <i className="bi bi-chevron-down" />
                </a>
                <ul>
                  <li>
                    <a href="#">
                      <b>Hii! Manish</b>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <img src={wallet2} alt="" />
                      <b>100050.00 EMO</b>
                    </a>
                  </li>
                  <li>
                    <NavLink to="/accountdetails">
                      <img src={profile} alt="" />
                      My profile
                    </NavLink>
                  </li>
                  <li>
                    <a href="#">
                      <img src={message} alt="" />
                      Notifications
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <img src={setting} alt="" />
                      Account settings
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <img src={language} alt="" />
                      Languages
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <img src={c} style={{ width: "20%" }} alt="" />
                      Currency
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <img src={wallet2} alt="" />
                      <b>Help Desk</b>
                    </a>
                  </li>
                  <li>
                    <NavLink to="/landing-page">
                      <img src={logout} alt="" />
                      Logout
                    </NavLink>
                  </li>
                </ul>
              </li>
            </ul>
          </nav>
        </div>
      </header>
    </>
  )
}
export default Header;
import { NavLink } from "react-router-dom";
function InnerSection({name,pageLink}) {
    return (
        <>
            <li className="nav-item">
                <NavLink className="nav-link" to={pageLink}>
                    {name}
                </NavLink>
            </li>
        </>
    )
}
export default InnerSection;
import { NavLink } from "react-router-dom";
function Footer() {
    return (

        <>
            <div className="footer-basic">
                <footer>
                    <ul className="list-inline">
                        <li className="list-inline-item">
                            <a href="#">Home</a>
                        </li>
                        <li className="list-inline-item">
                            <a href="#">Services</a>
                        </li>
                        <li className="list-inline-item">
                            <a href="#">About</a>
                        </li>
                        <li className="list-inline-item">
                            <NavLink to="/terms">Terms</NavLink>
                        </li>
                        <li className="list-inline-item">
                            <NavLink to="/privacy-policy">Privacy Policy</NavLink>
                        </li>
                    </ul>
                    <br />
                    <div className="social">
                        <a href="#">
                            <i className="icon ion-social-instagram" />
                        </a>
                        <a href="#">
                            <i className="icon ion-social-snapchat" />
                        </a>
                        <a href="#">
                            <i className="icon ion-social-twitter" />
                        </a>
                        <a href="#">
                            <i className="icon ion-social-facebook" />
                        </a>
                    </div>
                    <p className="dashboard-copyright">All Right Reserved Emopay.org</p>
                </footer>
            </div>
        </>
    )
}
export default Footer;
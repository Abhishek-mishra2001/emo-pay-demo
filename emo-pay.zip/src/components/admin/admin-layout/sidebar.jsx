import SideNavItem from "./side-nav-item";
import '../../../css/vertical-layout-light/style.css';
import SideBarInnerSection from "./sidebar-inner-section";
import {depositEmo,buypackage,myinvestment,blockExplorer,dashboard,transaction,accountDetail,myEmo,myincome,fundManager,rechargeBill,staking} from "../../store/data/sidebar-content";
function SideBar() {
    return (
        <>
            <nav className="sidebar sidebar-offcanvas" id="sidebar">
                <ul className="nav">
                  <SideNavItem name={dashboard} />
                    <SideBarInnerSection name={accountDetail} />
                    <SideNavItem name={depositEmo} />
                    <SideNavItem name={buypackage} />
                    <SideNavItem name={myinvestment} />
                    <SideNavItem name={blockExplorer} />
                    <SideBarInnerSection name={myEmo} />
                    <SideBarInnerSection name={myincome} />
                    <SideBarInnerSection name={fundManager} />
                    <SideBarInnerSection name={rechargeBill} />
                    <SideNavItem name={staking} />
                    <SideNavItem name={transaction} />
                </ul>
            </nav>
        </>
    )
}
export default SideBar;
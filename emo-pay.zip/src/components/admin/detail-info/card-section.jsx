import Card from "./card"
export default function CardSection() {
    class CardInfo {
        constructor(title, color, icon) {
            this.title = title;
            this.color = color;
            this.icon = icon;
        }
    }
    const payCard = new CardInfo('PAY', '#0060ac', 'bi-credit-card-2-front')
    const receiveCard = new CardInfo('RECEIVE', '#00906f', 'bi-cash-stack')
    const buyEmoCard = new CardInfo('Buy Emo/USDT', '#e6610e', 'bi-upload')
    const historyCard = new CardInfo('TRANSACTION HISTORY', '#e8b91f', 'bi-clock-history')
    return (
        <>
            <section id="" className="more-services services" style={{ paddingTop: "1px !important" }}>
                <div className="container text-center">
                    <div className="row">
                        <Card name={payCard} />
                        <Card name={receiveCard} />
                        <Card name={buyEmoCard} />
                        <Card name={historyCard} />
                    </div>
                </div>
            </section>
        </>
    )
}

export default function ShareLink() {
    return (
        <>
            <section id="features" className="features">
                <div className="container text-center">
                    <div className="share-link a" style={{ background: "-webkit-linear-gradient(left, #003366,#004080,#0059b3, #0073e6)" }}>
                        <h1>
                            <a href="invite-link">Share Link</a>
                        </h1>
                    </div>
                </div>
            </section>
        </>
    )
}
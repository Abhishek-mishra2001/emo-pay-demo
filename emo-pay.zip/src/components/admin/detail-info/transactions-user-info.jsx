import TransactionsInfo from "./transaction-info";
function TransactionUserInfo(){
    class EmoInfo{
        constructor(icon,count,type){
           this.icon = icon;
           this.count = count;
           this.type = type;
        }
    }
    const transaction = new EmoInfo('bx-money','25204','Total Transactions')
    const users = new EmoInfo('bx-user','23734','Users')
return(
<>
<section id="" className="more-services services" style={{ paddingTop: 0 }}>
  <div className="container text-center">
    <div className="row">
      <TransactionsInfo name={transaction} />
      <TransactionsInfo name={users} />
    </div>
  </div>
</section>
</>
    )
}
export default TransactionUserInfo;
function BankingFeatures({name}) {
    return (
        <>
            <div className="col-md-2 col-sm">
                <div className="icon-boxes text-center red">
                    <span className="dot-active" />
                    <img src={name.img} alt="" style={{ padding: name.style, width:name.widthOpt }} />
                    <br />
                    <h3>
                        <a href="#">{name.title}</a>
                    </h3>
                </div>
            </div>
        </>
    )
}
export default BankingFeatures;
import CommonInfo from "./common-info";
function MoreService(){
    class EmoInfo{
        constructor(name,buyemo,sellemo){
           this.name = name;
           this.buyemo = buyemo;
           this.sellemo = sellemo;
        }
    }
    const emoPrice = new EmoInfo('EMO PRICE','Buy 1 EMO = 0.5200 INR','Sell 1 EMO = 0.5200 INR')
    const walletBalance = new EmoInfo('Wallet Balance','1000 EMO','520 INR')
    return(
        <>
        <section id="" className="more-services services" style={{ paddingTop: 0 }}>
                <div className="container text-center">
                    <div className="row">
                      <CommonInfo name={emoPrice}/>  
                      <CommonInfo name={walletBalance}/>
                    </div>
                </div>
            </section>
        </>
    )
}
export default MoreService;
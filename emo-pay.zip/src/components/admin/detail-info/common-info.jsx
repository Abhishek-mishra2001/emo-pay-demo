import '../../../assets/css/style.css';
function CommonInfo({name}) {
    return (
        <>
            <div className="col d-flex align-items-stretch">
                <div className="card" style={{ paddingTop: 60 }}>
                    <div className="card-body">
                        <span className="dot-active" />
                        <h3 style={{ fontWeight: 700, color: "#0060ac" }}>{name.name}</h3>
                        <h4>{name.buyemo}</h4>
                        <h4>{name.sellemo}</h4>
                    </div>
                </div>
            </div>
        </>
    )
}

export default CommonInfo;
import BankingFeatures from "./banking-features"
import phoneImg from '../../../assets/img/phone.svg';
import uploadImg from '../../../assets/img/upload.svg';
import usersImg from '../../../assets/img/users.svg';
import onlineStoreImg from '../../../assets/img/online_store.svg';
import donationImg from '../../../assets/img/donation.svg';
import stakingImg from '../../../assets/img/staking.svg';
import payImg from '../../../assets/img/pay.svg';
import gameImg from '../../../assets/img/game.svg';
import offlineStoreImg from '../../../assets/img/offline_store.svg';
import settingImg from '../../../assets/img/setting.svg';
function BankingInfo() {
    class BankingDetail {
        constructor(title, img, style, widthOpt) {
            this.title = title;
            this.img = img;
            this.style = style;
            this.widthOpt = widthOpt;
        }
    }
    const stake = new BankingDetail('Stake', stakingImg, '10px')
    const phone = new BankingDetail('Recharge', phoneImg, '10px', '60%')
    const upload = new BankingDetail('Upload EMO', uploadImg, '10px', '80%')
    const users = new BankingDetail(`My Emoian's`, usersImg, '20px', '80%')
    const sellEmo = new BankingDetail(`SELL EMO with Authorised Banks`, stakingImg, '10px')
    const onlineStore = new BankingDetail('SELL EMO/USDT', onlineStoreImg, '10px')
    const withdrawalEmo = new BankingDetail('Withdrawal EMO to Wallet', uploadImg, '10px', '80%')
    const donation = new BankingDetail('Donation', donationImg, '10px')
    const buyEmo = new BankingDetail('Buy EMO with Credit/Debit Cards', payImg, '10px','60%')
    const games = new BankingDetail('Games', gameImg,'10px','60%')
    const shops = new BankingDetail('Shops', offlineStoreImg,'10px','90%')
    const services = new BankingDetail('Services', settingImg,'15px','60%')
    const emoValley = new BankingDetail('EMOValley', phoneImg,'10px','60%')
    return (
        <>
            <section id="features" className="features">
                <div className="container">
                    <div className="row">
                        <BankingFeatures name={stake} />
                        <BankingFeatures name={phone} />
                        <BankingFeatures name={upload} />
                        <BankingFeatures name={users} />
                        <BankingFeatures name={sellEmo} />
                        <BankingFeatures name={onlineStore} />
                        <BankingFeatures name={withdrawalEmo} />
                        <BankingFeatures name={donation} />
                    </div>
                </div>
            </section>
            <br />
            <hr />
            <section id="features" className="features" style={{ paddingBottom: 150 }}>
                <div className="container">
                    <div className="row">
                    <BankingFeatures name={buyEmo} />
                    <BankingFeatures name={games} />
                    <BankingFeatures name={shops} />
                    <BankingFeatures name={services} />
                    <BankingFeatures name={emoValley} />
                    </div>
                </div>
            </section>

        </>
    )
}
export default BankingInfo;
function TransactionsInfo({name}){
    return(
        <>
        <div className="col d-flex align-items-stretch">
        <div className="card">
          <div className="card-body">
            <span className="dot-active" />
            <div className="icon">
              <i className={`bx ${name.icon}`} />
            </div>
            <h4>{name.count}</h4>
            <h4 className="title">
              <a href="#0">{name.type}</a>
            </h4>
            <h1>
              <a href="#">
                <i
                  className="bi bi-arrow-right-circle-fill"
                  style={{ color: "#e8b91f" }}
                />
              </a>
            </h1>
          </div>
        </div>
      </div>
        </>
    )
}
export default TransactionsInfo;
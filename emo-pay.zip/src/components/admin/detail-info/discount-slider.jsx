import banner1 from '../../../assets/img/banner1.jpeg';
function DiscountSlider() {
    return (
        <>
            <div id="slider" style={{ paddingTop: 50, paddingBottom: 60 }}>
                <figure>
                    <img src={banner1} alt="" />
                    <img src={banner1} alt="" />
                    <img src={banner1} alt="" />
                    <img src={banner1} alt="" />
                    <img src={banner1} alt="" />
                </figure>
            </div>

        </>
    )
}
export default DiscountSlider;
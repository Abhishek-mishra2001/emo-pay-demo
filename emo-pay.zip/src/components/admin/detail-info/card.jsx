export default function Card({name}) {
    return (
        <>
            <div className="col d-flex align-items-stretch">
                <div className="card">
                    <div className="card-body2" style={{ paddingTop: 10 }}>
                        <div className="icon2" style={{ backgroundColor: name.color }}>
                            <i className={`bi ${name.icon}`} />
                        </div>
                        <p className="card-title">
                            <a href="#">{name.title}</a>
                        </p>
                    </div>
                </div>
            </div>
        </>
    )
}
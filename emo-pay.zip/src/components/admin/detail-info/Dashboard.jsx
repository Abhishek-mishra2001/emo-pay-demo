import MoreService from './more-service';
import TransactionUserInfo from './transactions-user-info';
import ShareLink from './share-link';
import CardSection from './card-section';
import DiscountSlider from './discount-slider';
import BankingInfo from './banking-info';
import Footer from '../admin-layout/footer';
import Header from '../admin-layout/header';
function Dashboard() {
    return (
        <>
            <Header/>
            <div>
                <h1 align="center" className='heading-h1' style={{ paddingTop: 150, color: "#444444" }}>
                    <b>World's Most-Secure Decentralized Payment Platform</b>
                </h1>
            </div>
            <MoreService />
            <TransactionUserInfo />
            <ShareLink />
            <main id='main'>
                <CardSection />
                <DiscountSlider />
                {/* ======= BANKING ======= */}
                <div className="container">
                    <div>
                        <h1>
                            <b>EMOVERSE</b>
                        </h1>
                    </div>
                </div>
                <BankingInfo />
                <Footer/>
            </main>
        </>
    )
}
export default Dashboard;
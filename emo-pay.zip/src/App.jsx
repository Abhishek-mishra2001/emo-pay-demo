import Dashboard from "./components/admin/detail-info/Dashboard"
import { Route,Routes } from "react-router-dom";
import Accountdetails from "./components/admin/profile/accountdetails";
import EditWalletAddress from "./components/admin/profile/edit-wallet-address";
import DepositeEmo from "./components/admin/profile/deposite-emo";
import MyInvestment from "./components/admin/profile/myinvestment";
import MyDirectEmonians from "./components/admin/profile/my-direct-emonians";
import TeamLevelEmonians from "./components/admin/profile/team-level-emonians";
import DailyIncome from "./components/admin/profile/daily-income";
import DailyStakeReturn from "./components/admin/profile/daily-stake-return";
import WithdrawalDetails from "./components/admin/profile/withdrawal-details";
import TranSactions from "./components/admin/profile/transactions";
import ChangePassword from "./components/authentication/change-password";
import ChangeTransactionPassword from "./components/authentication/change-transaction-password";
import BlockExplorer from "./components/admin/profile/block-explorer";
import WalletTransfer from "./components/admin/profile/wallet-transfer";
import WalletWithdrawal from "./components/admin/profile/wallet-withdrawal";
import Buypackage from "./components/admin/profile/buy-package";
import Layout from "./components/authentication/layout";
import LandingPage from "./components/landing-page/landing-page";
import PrivacyPolicy from "./components/landing-page/privacy-policy";
import Terms from "./components/landing-page/terms";
import WalletRecieve from "./components/admin/profile/walletreceive";
import Staking from "./components/admin/profile/staking";
import MobileRecharge from "./components/admin/profile/mobile-recharge";
import Eletricity from "./components/admin/profile/electricity";
import Dth from "./components/admin/profile/dth";
import { useLocation } from "react-router-dom";
function App() {
  const path = useLocation();
  if(path.pathname == '/landing-page' || path.pathname=='/terms' || path.pathname=='/privacy-policy' || path.pathname=='/'){
     import('./assets/landing-page-assets/css/swiper.css');
     import('./assets/landing-page-assets/js/scripts.js');
  }else if(path.pathname == '/login'){
      import('./assets/css/auth.css');
       import ('./assets/js/canvas.js')
  }
  return (
    <Routes>
    <Route path="/login"  element={<Layout/>} />
      <Route path="/accountdetails" element={<Accountdetails/>} />
      <Route path="/accountdetails/editwalletaddress" element={<EditWalletAddress/>} />
      <Route path="/dashboard"  element={<Dashboard/>} />
      <Route path="/deposite-emo"  element={<DepositeEmo/>} />
      <Route path="/myinvestment"  element={<MyInvestment/>} />
      <Route path="/direct-emonians"  element={<MyDirectEmonians/>} />
      <Route path="/team-level-emonians"  element={<TeamLevelEmonians/>} />
      <Route path="/daily-income"  element={<DailyIncome/>} />
      <Route path="/daily-stake-return"  element={<DailyStakeReturn/>} />
      <Route path="/withdrawal-details"  element={<WithdrawalDetails/>} />
      <Route path="/transactions"  element={<TranSactions/>} />
      <Route path="/change-password"  element={<ChangePassword/>} />
      <Route path="/change-transactions-password"  element={<ChangeTransactionPassword/>} />
      <Route path="/block-explorer"  element={<BlockExplorer/>} />
      <Route path="/wallet-transfer"  element={<WalletTransfer/>} />
      <Route path="/wallet-withdrawal"  element={<WalletWithdrawal/>} />
      <Route path="/buy-package"  element={<Buypackage/>} />
      <Route path="/dashboard"  element={<Dashboard/>} />
      <Route path="/"  element={<LandingPage/>} exact />
      <Route path="/landing-page"  element={<LandingPage/>} />
      <Route path="/privacy-policy"  element={<PrivacyPolicy/>} />
      <Route path="/terms"  element={<Terms/>} />
      <Route path="/wallet-recieve"  element={<WalletRecieve/>} />
      <Route path="/staking"  element={<Staking/>} />
      <Route path="/mobile-recharge"  element={<MobileRecharge/>} />
      <Route path="/eletricity"  element={<Eletricity/>} />
      <Route path="/dth"  element={<Dth/>} />
    </Routes>
  )
}

export default App
